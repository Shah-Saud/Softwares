package com.example.progro.Inventory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.progro.Inventory.Fertilizers.Fertilizers;
import com.example.progro.Inventory.Seeds.Inventory_Seeds;
import com.example.progro.Inventory.Stock.Stock;
import com.example.progro.Inventory.Tools.Tools;
import com.example.progro.R;


public class Inventory_Menu extends AppCompatActivity {
    CardView tools,seeds,fertilizer,stock,cattle,cattle_feed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_menu);

        tools = (CardView) findViewById(R.id.tools);
        seeds = (CardView) findViewById(R.id.seeds);
        fertilizer = (CardView) findViewById(R.id.fertilizer);
        stock = (CardView) findViewById(R.id.crops_stock);



        tools.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Inventory_Menu.this.startActivity(new Intent(Inventory_Menu.this.getApplicationContext(), Tools.class));
            }
        });

        seeds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Inventory_Menu.this.startActivity(new Intent(Inventory_Menu.this.getApplicationContext(), Inventory_Seeds.class));
            }
        });

        fertilizer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Inventory_Menu.this.startActivity(new Intent(Inventory_Menu.this.getApplicationContext(), Fertilizers.class));
            }
        });

        stock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Inventory_Menu.this.startActivity(new Intent(Inventory_Menu.this.getApplicationContext(), Stock.class));
            }
        });
    }
}