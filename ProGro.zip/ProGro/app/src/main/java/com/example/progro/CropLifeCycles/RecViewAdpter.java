package com.example.progro.CropLifeCycles;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.progro.R;

import java.util.ArrayList;

public class RecViewAdpter  extends RecyclerView.Adapter<RecViewAdpter.ViewHolder> {
    private static final String Tag = "RecyclerView";
    private Context mContext;
    private ArrayList<Model> modelList;

    public RecViewAdpter(Context mContext, ArrayList<Model> modelList) {
        this.mContext = mContext;
        this.modelList = modelList;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_lifecycles, parent, false));
    }

    @Override
    public void onBindViewHolder(RecViewAdpter.ViewHolder holder, int position) {
        holder.name.setText(this.modelList.get(position).getName());
        holder.desc.setText(this.modelList.get(position).getDescription());
        Glide.with(this.mContext).load(this.modelList.get(position).getImg()).into(holder.img);

    }

    @Override
    public int getItemCount() {
        return this.modelList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView desc;
        ImageView img;
        TextView name;

        public ViewHolder(View itemView) {
            super(itemView);
            this.name = (TextView) itemView.findViewById(R.id.NameText);
            this.img = (ImageView) itemView.findViewById(R.id.LifeImg);
            this.desc = (TextView) itemView.findViewById(R.id.DescText);
        }
    }
}
