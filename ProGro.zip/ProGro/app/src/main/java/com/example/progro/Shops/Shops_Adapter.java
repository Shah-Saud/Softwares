package com.example.progro.Shops;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.progro.Inventory.Fertilizers.Inventory_Fertilizers_Addrec;
import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import org.jetbrains.annotations.NotNull;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.progro.R.drawable.*;

public class Shops_Adapter extends FirebaseRecyclerAdapter<Shops_Model,Shops_Adapter.myViewHolder> {
    public static String mapLink;
    private LayoutInflater mInflater;
    private Context mcon;
    WebView webView;

    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public Shops_Adapter(@NonNull @NotNull FirebaseRecyclerOptions<Shops_Model> options) {
        super(options);
    }



    @Override
    protected void onBindViewHolder(myViewHolder holder, int position, Shops_Model model) {
        holder.name.setText(model.getShopName());
        holder.address.setText(model.getAddress());
        holder.img.setImageResource(shopimg2);
        mapLink = model.getAddress();


        holder.btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                final DialogPlus dialogPlus = DialogPlus.newDialog(holder.name.getContext())
                        .setContentHolder(new ViewHolder(R.layout.shops_map))
                        .setExpanded(true,1200).create();



                //dialogPlus.show();

                View view = dialogPlus.getHolderView();
                WebView webView = view.findViewById(R.id.webview);
                Button btnBack = view.findViewById(R.id.btnBack);

                webView.setWebViewClient(new WebViewClient());
                webView.loadUrl(model.getMapLink());

                WebSettings webSettings = webView.getSettings();
                webSettings.setJavaScriptEnabled(true);


                dialogPlus.show();


                btnBack.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialogPlus.dismiss();
                    }
                });
            }
        });






    }

    @NonNull
    @NotNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.shops_single_row,parent,false);
        return new Shops_Adapter.myViewHolder(view);
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView name,address;
        CircleImageView img;

        Button btnMap;

        public myViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.txt_name);
            address=(TextView) itemView.findViewById(R.id.txt_address);
            img = (CircleImageView) itemView.findViewById(R.id.img1);

            btnMap = (Button) itemView.findViewById(R.id.btnMap);


        }
    }
}
