package com.example.progro.Seeds_Germintation;

public class Seeds_Model {

    String Area;
    String Kind;
    String Sowing;

    Seeds_Model() {
    }

    public Seeds_Model(String area, String kind, String sowing) {
        this.Area = area;
        this.Kind = kind;
        this.Sowing = sowing;
    }

    public String getArea() {
        return this.Area;
    }

    public void setArea(String area) {
        this.Area = area;
    }

    public String getKind() {
        return this.Kind;
    }

    public void setKind(String kind) {
        this.Kind = kind;
    }

    public String getSowing() {
        return this.Sowing;
    }

    public void setSowing(String sowing) {
        this.Sowing = sowing;
    }
}
