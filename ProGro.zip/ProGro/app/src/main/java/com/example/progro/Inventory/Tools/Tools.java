package com.example.progro.Inventory.Tools;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.LoadingDailog;
import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import io.paperdb.Paper;

public class Tools extends AppCompatActivity {



    private TextView noDatatv;
    Tools_Adapter myAdpter;
    RecyclerView recview;
    FloatingActionButton floatingActionButton;

    //getting phonenumber of user
    String Phone = Paper.book().read("Phone");
    String child="Tools";
    DatabaseReference checkRef = FirebaseDatabase.getInstance().getReference("Inventory/" + Phone + "/Tools");


    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tools);

        showLoading();

        floatingActionButton=findViewById(R.id.floatingBtn);
        noDatatv = findViewById(R.id.noData_txt);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rec_view_tools);
        recview = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
            Tools_Adapter myAdpter1 = new Tools_Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance()
                    .getReference().child("Inventory/" + Phone + "/Tools"), Tools_Model.class).build(),getApplicationContext());
            myAdpter = myAdpter1;
            recview.setAdapter(myAdpter1);

            CheckData(Phone,child);


        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),tools_add_rec.class));
            }
        });




    }

    private void CheckData(String phone, String child) {
        checkRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if(snapshot.hasChildren()){
                    noDatatv.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }

    public void onStart() {
        super.onStart();
        myAdpter.startListening();
    }


    @Override
    public void onStop() {
        super.onStop();
        myAdpter.stopListening();
    }

    //this method is for loading dialog

    public void showLoading(){
        final LoadingDailog loadingDailog = new LoadingDailog(Tools.this);
        loadingDailog.startLoading();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDailog.closeLoading();
            }
        } ,5000);
    }


}