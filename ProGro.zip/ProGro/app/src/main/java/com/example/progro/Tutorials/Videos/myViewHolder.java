package com.example.progro.Tutorials.Videos;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.core.content.ContextCompat;
import androidx.media2.exoplayer.external.source.ExtractorMediaSource;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.R;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.MediaSourceFactory;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;

import org.jetbrains.annotations.NotNull;




public class myViewHolder extends RecyclerView.ViewHolder {
    private PlayerView playerView;
    SimpleExoPlayer player;
    TextView vtTitle;
    boolean fullScreen = false;
    ImageView fullScreen_button,download_button;
    String title,url;
    private int currentWindow =0;
    private long playbackPosition = 0;


    public myViewHolder(@NotNull View itemView) {
        super(itemView);
        vtTitle = itemView.findViewById(R.id.video_title);
        playerView =(PlayerView) itemView.findViewById(R.id.video_link);
        fullScreen_button = playerView.findViewById(R.id.exoplayer_fullscreen_icon);
        download_button = itemView.findViewById(R.id.download_btn);


    }

    //Preapring Media Source for Exoplayer
    private MediaSource buildMediaSource(Uri uri) {
        DefaultHttpDataSourceFactory dataSourceFactory = new DefaultHttpDataSourceFactory("Videos");
        return new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(uri);
    }

   @SuppressLint("RestrictedApi")
   public void SetVideo(final Videos application, String Title, final String VideoLink){


       vtTitle.setText(Title);


try {

    //Alternative code of exoplayer

//    TrackSelector trackSelector;
//    trackSelector = new DefaultTrackSelector(new AdaptiveTrackSelection.Factory());
//    Uri video = Uri.parse(VideoLink);
//    DefaultHttpDataSourceFactory dataSourceFactory = new DefaultHttpDataSourceFactory("Videos");
//
//    MediaSourceFactory mediaSourceFactory =
//            new DefaultMediaSourceFactory(dataSourceFactory);
//    player =  new SimpleExoPlayer.Builder(application)
//            .setMediaSourceFactory(mediaSourceFactory)
//            .setTrackSelector(trackSelector)
//            .build();
//
//    playerView.setPlayer( player);
//    player.seekTo(currentWindow,playbackPosition);
//    player.setMediaItem(MediaItem.fromUri(video));
//    player.setPlayWhenReady(false);



    player =  new com.google.android.exoplayer2.SimpleExoPlayer.Builder(application).build();

    playerView.setPlayer(player);
    Uri uri = Uri.parse(VideoLink);
    MediaSource mediaSource = buildMediaSource(uri);
    player.setPlayWhenReady(false);
    player.seekTo(currentWindow,playbackPosition);
    player.prepare(mediaSource,false,false);

}catch (Exception e){

    Toast.makeText(application, "Player Error Try Again", Toast.LENGTH_SHORT).show();
}



       fullScreen_button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               title = Title;
               url = VideoLink;
               Intent intent = new Intent(application,FullScreen_Video.class);
               intent.putExtra("tl",title);
               intent.putExtra("ur",url);
               player.stop();
               application.startActivity(intent);


           }
       });

   }


}
