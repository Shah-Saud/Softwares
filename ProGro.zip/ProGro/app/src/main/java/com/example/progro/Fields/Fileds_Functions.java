package com.example.progro.Fields;

public class Fileds_Functions {
//    public static String [] landTypes= {"Silty","Sandy","Clayey","Loamy","Calcareous","Clayey and Silty","Clayey and Sandy","Loamy and Silty"};
//
//    public static ArrayAdapter<String> adapterLand;
//    public static NumberPicker numberPicker,yieldPicker;
//    public static DatePicker datePicker;
//    public  static Spinner landType;
//
//    public static void SetMyNumberPicker(Activity activity){
//        //Number picker for land size
//        numberPicker = (NumberPicker) activity.findViewById(R.id.fieldSize_picker);
//        numberPicker.setMax(999999);
//        numberPicker.setMin(5);
//        numberPicker.setUnit(1);
//        numberPicker.setValue(10);
//
//        //Number picker for yield
//        yieldPicker = (NumberPicker) activity.findViewById(R.id.Yield_picker);
//        yieldPicker.setMax(999999);
//        yieldPicker.setMin(5);
//        yieldPicker.setUnit(5);
//        yieldPicker.setValue(10);
//    }
//
//    public static void SetMyDatePicker(Activity activity){
//        datePicker = activity.get.findViewById(R.id.datePicker);
//
//       datePicker.findViewById(activity.getResources().getIdentifier("day","id","android")).setVisibility(View.GONE);
//    }
//
//    public static void LoadLandTypes(Activity activity) {
//
//        landType = (Spinner) activity.findViewById(R.id.spinnerLand);
//        adapterLand = new ArrayAdapter<String>(activity, R.layout.support_simple_spinner_dropdown_item, landTypes);
//        landType.setAdapter(adapterLand);
//
//
//
//    }

//    public static void LoadLandTypes(Activity activity,String theDefaultValue) {
//
//        landType = (Spinner) activity.findViewById(R.id.spinnerLand);
//        adapterLand = new ArrayAdapter<String>(activity, R.layout.support_simple_spinner_dropdown_item, landTypes);
//        landType.setAdapter(adapterLand);
//
//
//        int spinnerPosition = adapterLand.getPosition(theDefaultValue);
//        landType.setSelection(spinnerPosition);
//    }
}
