package com.example.progro.CropsVarity;

public class Variety_Model {

    String Name;
    String PotentialYield;
    String Year;

    Variety_Model() {
    }

    public Variety_Model(String name, String potentialYield, String year) {
        this.Name = name;
        this.PotentialYield = potentialYield;
        this.Year = year;
    }

    public String getName() {
        return this.Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getPotentialYield() {
        return this.PotentialYield;
    }

    public void setPotentialYield(String potentialYield) {
        this.PotentialYield = potentialYield;
    }

    public String getYear() {
        return this.Year;
    }

    public void setYear(String year) {
        this.Year = year;
    }
}
