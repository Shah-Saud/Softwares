package com.example.progro.Tutorials;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.progro.R;
import com.example.progro.Tasks.NewTasks.Tasks_Adapter;
import com.example.progro.Tasks.Tasks_Model;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Tutorials extends AppCompatActivity {
    Tutorials_Adapter myAdpter;
    RecyclerView recview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorials);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rec_view_videos);
        recview = recyclerView;


//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        Tutorials_Adapter myAdpter1 = new Tutorials_Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance()
//                .getReference().child("Tutorials/Cat"), Model_Tutorials.class).build(),getApplicationContext());

        recyclerView.setLayoutManager(new GridLayoutManager(this,3));
        Tutorials_Adapter myAdpter1 = new Tutorials_Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance()
               .getReference().child("Tutorials/Cat"), Model_Tutorials.class).build(),getApplicationContext());
        myAdpter = myAdpter1;
        recview.setAdapter(myAdpter1);
    }

    public void onStart() {
        super.onStart();
        myAdpter.startListening();
    }


    @Override
    public void onStop() {
        super.onStop();
        myAdpter.stopListening();
    }
}