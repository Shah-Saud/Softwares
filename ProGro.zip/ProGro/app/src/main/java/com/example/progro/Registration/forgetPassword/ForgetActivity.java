package com.example.progro.Registration.forgetPassword;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.progro.R;
import com.example.progro.Registration.login.LoginActivity;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ForgetActivity extends AppCompatActivity {
    EditText newpass, cnfrmPass;
    DatabaseReference dbRef;
    String phoneNumber;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget);

        dbRef = FirebaseDatabase.getInstance().getReference("Users");

        newpass = findViewById(R.id.newpass);
        cnfrmPass = findViewById(R.id.cnfrm_pass);
        context = this;
        phoneNumber = getIntent().getStringExtra("contact");
    }

    public void forgetBtn(View view) {

        String password, cnfrm_Pass;
        password = newpass.getText().toString();
        cnfrm_Pass = cnfrmPass.getText().toString();

        if (!TextUtils.isEmpty(password)) {
            if (password.length() > 6) {

                if (!TextUtils.isEmpty(cnfrm_Pass)) {
                    if (password.equals(cnfrm_Pass)) {

                        dbRef.child(phoneNumber).child("password").setValue(password).addOnSuccessListener(ForgetActivity.this, new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(context, "Updated successfully", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(context, LoginActivity.class));
                                finish();
                            }
                        });
                    }
                    else {

                        Toast.makeText(this, "Password must be same", Toast.LENGTH_SHORT).show();
//                            cnfrmPass.setError("Password must be same");
                    }
                }
                else {


                    Toast.makeText(this, "Please confirm your Password", Toast.LENGTH_SHORT).show();
                }
            }
            else {

                Toast.makeText(this, "Password should contains 7 letters", Toast.LENGTH_SHORT).show();
            }


        } else {

            Toast.makeText(this, "Please enter your Password", Toast.LENGTH_SHORT).show();
        }

    }
}