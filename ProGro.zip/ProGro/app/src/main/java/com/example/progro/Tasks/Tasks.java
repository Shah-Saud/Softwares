package com.example.progro.Tasks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.progro.MainActivity;
import com.example.progro.R;
import com.example.progro.Tasks.MyTasks.My_Tasks;
import com.example.progro.Tasks.NewTasks.New_Tasks;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class Tasks extends AppCompatActivity {
    private AdView mAdView;
    CardView newTasks,myTasks;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tasks_menu);

        //Ad code
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        newTasks =(CardView) findViewById(R.id.newTasks);
        myTasks =(CardView) findViewById(R.id.myTasks);


        newTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tasks.this.startActivity(new Intent(Tasks.this.getApplicationContext(), New_Tasks.class));
            }
        });


        myTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tasks.this.startActivity(new Intent(Tasks.this.getApplicationContext(), My_Tasks.class));
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }
}