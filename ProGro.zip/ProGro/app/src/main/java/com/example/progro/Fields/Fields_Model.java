package com.example.progro.Fields;

public class Fields_Model {
    String Crop;
    String Fertilizers;
    String Field_Name;
    String Field_Size;
    String Land_Type;
    String Status;
    String Year;
    String Yield;
    String Phone;
    String Key;

    public Fields_Model() {
    }

    public Fields_Model(String crop, String fertilizers, String field_Name, String field_Size, String land_Type, String status, String year, String yield,String phone,String key) {
        Crop = crop;
        Fertilizers = fertilizers;
        Field_Name = field_Name;
        Field_Size = field_Size;
        Land_Type = land_Type;
        Status = status;
        Year = year;
        Yield = yield;
        Phone = phone;
        Key=key;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getCrop() {
        return Crop;
    }

    public void setCrop(String crop) {
        Crop = crop;
    }

    public String getFertilizers() {
        return Fertilizers;
    }

    public void setFertilizers(String fertilizers) {
        Fertilizers = fertilizers;
    }

    public String getField_Name() {
        return Field_Name;
    }

    public void setField_Name(String field_Name) {
        Field_Name = field_Name;
    }

    public String getField_Size() {
        return Field_Size;
    }

    public void setField_Size(String field_Size) {
        Field_Size = field_Size;
    }

    public String getLand_Type() {
        return Land_Type;
    }

    public void setLand_Type(String land_Type) {
        Land_Type = land_Type;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public String getYield() {
        return Yield;
    }

    public void setYield(String yield) {
        Yield = yield;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }
}
