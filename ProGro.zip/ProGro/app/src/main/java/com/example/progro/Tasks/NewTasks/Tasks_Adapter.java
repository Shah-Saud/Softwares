package com.example.progro.Tasks.NewTasks;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.progro.R;
import com.example.progro.Tasks.Tasks_Model;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import io.paperdb.Paper;

public class Tasks_Adapter extends FirebaseRecyclerAdapter<Tasks_Model,Tasks_Adapter.myViewHolder> {
   public static String T_Name,T_Date,T_Img;
   boolean testClick=false;

    String Phone = Paper.book().read("Phone");
    String Province = Paper.book().read("Province");
    String City = Paper.book().read("City");


    public Tasks_Adapter(@NonNull @NotNull FirebaseRecyclerOptions<Tasks_Model> options) {
        super(options);

    }


    @Override
    protected void onBindViewHolder(@NonNull @NotNull myViewHolder holder, int position, @NonNull @NotNull Tasks_Model model) {




        holder.Name.setText(model.getName());
        holder.landType.setText(model.getLandType());
        holder.Date.setText(model.getDate());

        Glide.with(holder.img.getContext())
                .load(model.getImg())
                .placeholder(R.drawable.loading)
                .circleCrop()
                .error(R.drawable.error)
                .into(holder.img);


        String userId = Phone;
        String taskId = getRef(position).getKey();

        holder.followBtn(taskId,userId);





        holder.btnFollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Map<String,Object> map = new HashMap<>();

                map.put("Name",model.getName());
                map.put("Date",model.getDate());
                map.put("Img",model.getImg());

                FirebaseDatabase.getInstance().getReference().child("Tasks/FollowedTasks/"+ Province+"/"+City+"/"+Phone+"/"+taskId)
                        .setValue(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(holder.Name.getContext(), "You have followed this task", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull @NotNull Exception e) {
                        Toast.makeText(holder.Name.getContext(), "Task cannot be followed try again", Toast.LENGTH_SHORT).show();
                    }
                });

//                Log.d("data",map.toString());



            }
        });


    }

    @NonNull
    @NotNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_tasks_single_row,parent,false);
        return new Tasks_Adapter.myViewHolder(view);
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView Name,Date,landType;
        CircleImageView img;
        DatabaseReference followedRef;
        Button btnFollow;

        public myViewHolder(View itemView) {
            super(itemView);
            Name = (TextView) itemView.findViewById(R.id.txt_name);
            Date=(TextView) itemView.findViewById(R.id.txt_date);
            landType = (TextView) itemView.findViewById(R.id.txt_type);
            img = (CircleImageView) itemView.findViewById(R.id.img1);

            btnFollow = (Button) itemView.findViewById(R.id.btnFollow);






        }

        //This is for change=ing color of the button if user have followed the tasks already

        public void followBtn(final String taskId,final String userId) {
            followedRef = FirebaseDatabase.getInstance().getReference("Tasks/FollowedTasks/"+Province+"/"+City+"/"+Phone);

            followedRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {

                    if(snapshot.getKey().equals(Phone) && snapshot.hasChild(taskId)){

                        btnFollow.setBackgroundTintList(ColorStateList.valueOf(Color.GRAY));
                        btnFollow.setEnabled(false);
                        btnFollow.setText("Followed");

                        //Log.d("myTag", "Followed");

                    }else {
                        btnFollow.setText("Follow");
                        btnFollow.setEnabled(true);
                        //14329120
                        btnFollow.setBackgroundTintList(ColorStateList.valueOf(14329120));
                    }


                    //Log.d("myTag", snapshot.getKey()+" Child "+ snapshot.getValue());

                    //this part will be implemented when we inset data from AdminPanel



                }

                @Override
                public void onCancelled(@NonNull @NotNull DatabaseError error) {

                }
            });

        }
    }





}
