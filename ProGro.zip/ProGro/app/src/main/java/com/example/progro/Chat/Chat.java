package com.example.progro.Chat;

import android.Manifest;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.BuildConfig;
import com.example.progro.R;
import com.example.progro.Registration.SharePrefence;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class Chat extends AppCompatActivity {

    private final List<Messages> messagesList = new ArrayList<>();
    Gson gson;
    TextView textView,chatData;
    private String messageReceiverID, messageReceiverName, messageReceiverImage, messageSenderID;
    private TextView userName, userLastSeen;
    private CircleImageView userImage;
    private Toolbar ChatToolBar;
    private FirebaseAuth mAuth;
    private DatabaseReference RootRef;
    private ImageButton SendMessageButton, SendFilesButton;
    private EditText MessageInputText;
    private LinearLayoutManager linearLayoutManager;
    private MessageAdapter messageAdapter;
    private RecyclerView userMessagesList;
    private String roomId;
    private String saveCurrentTime, saveCurrentDate;
    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int REQUEST_READ_EXTERNAL_STORAGE = 10;
    private Uri mImageUri;
    private StorageReference mStorageRef;
    private StorageTask mUploadTask;
    private ProgressBar mProgressBar;
    File file;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        gson = new Gson();
        textView = findViewById(R.id.text_toolbar_title);
        chatData=findViewById(R.id.chat_data);
        SharePrefence.init(this);
        mProgressBar = findViewById(R.id.progress_bar);

        messageSenderID = getIntent().getExtras().get("user_id").toString();

        RootRef = FirebaseDatabase.getInstance().getReference();
        mStorageRef = FirebaseStorage.getInstance().getReference("uploads");


        messageReceiverID = getIntent().getExtras().get("visit_user_id").toString();
        messageReceiverName = getIntent().getExtras().get("visit_user_name").toString();
        textView.setText(messageReceiverName);

        setRead();
        //messageReceiverImage = getIntent().getExtras().get("visit_image").toString();

        messageReceiverImage = "";
        IntializeControllers();
        Log.e("tag", "onCreate: " + messageReceiverID + " " + messageReceiverName);
        Log.e("tag", "messageSenderId" + messageSenderID + "  messageReciverId" + messageReceiverID);


        // Glide.with(this).load(messageReceiverImage).placeholder(R.drawable.com_facebook_profile_picture_blank_portrait).into(userImage);


        SendMessageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //createRoom();
                SendMessage("");

            }
        });
        RootRef.child("Messages").child(messageSenderID).child(messageReceiverID)
                .addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                        Messages messages = dataSnapshot.getValue(Messages.class);

                        messagesList.add(messages);

                        messageAdapter.notifyDataSetChanged();

                        userMessagesList.smoothScrollToPosition(userMessagesList.getAdapter().getItemCount());
                        if(messagesList.isEmpty())
                        {
                            chatData.setVisibility(View.VISIBLE);
                            Log.d("Messages",messages.messageID+"");
                        }
                        else
                        {
                            chatData.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onChildRemoved(DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });


        //DisplayLastSeen();
    }

    private void IntializeControllers() {

        SendMessageButton = findViewById(R.id.send_message_btn);
        // SendFilesButton = findViewById(R.id.send_files_btn);
        MessageInputText = findViewById(R.id.input_message);

        messageAdapter = new MessageAdapter(messagesList, this, messageSenderID);
        Log.e("tag", "previousMessages" + messagesList);
        userMessagesList = (RecyclerView) findViewById(R.id.private_messages_list_of_users);
        linearLayoutManager = new LinearLayoutManager(this);
        userMessagesList.setLayoutManager(linearLayoutManager);
        userMessagesList.setAdapter(messageAdapter);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("MMM dd, yyyy");
        saveCurrentDate = currentDate.format(calendar.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("hh:mm a");
        saveCurrentTime = currentTime.format(calendar.getTime());
    }




    @Override
    protected void onStart() {
        super.onStart();
        roomId = messageSenderID + "-" + messageReceiverID;



    }


    private void SendMessage(String imgUrl) {
        String messageText = MessageInputText.getText().toString();

        if (TextUtils.isEmpty(messageText) && TextUtils.isEmpty(imgUrl)) {
            Toast.makeText(this, "first write your message...", Toast.LENGTH_SHORT).show();
        } else {

            String messageSenderRef = "Messages/" + messageSenderID + "/" + messageReceiverID;

            DatabaseReference userMessageKeyRef = RootRef.child("Messages")
                    .child(messageSenderID).child(messageReceiverID).push();

            String messagePushID = userMessageKeyRef.getKey();

            Map messageTextBody = new HashMap();
            messageTextBody.put("message", messageText);
            messageTextBody.put("type", "text");
            messageTextBody.put("from", messageReceiverID);
            messageTextBody.put("to", messageSenderID);
            messageTextBody.put("messageID", messagePushID);
            messageTextBody.put("time", saveCurrentTime);
            messageTextBody.put("date", saveCurrentDate);
            messageTextBody.put("imageUrl", imgUrl);

            Map messageBodyDetails = new HashMap();
            messageBodyDetails.put(messageSenderRef + "/" + messagePushID, messageTextBody);

            RootRef.updateChildren(messageBodyDetails).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(Chat.this, "Message Sent Successfully...", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Chat.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                    MessageInputText.setText("");
                }
            });
        }
    }

    public void CallMobile(View view) {
        Intent callIntent = new Intent(Intent.ACTION_DIAL);
        callIntent.setData(Uri.parse("tel:" + messageSenderID));
        startActivity(callIntent);
    }

    public void deletChat(View view) {
        RootRef.child("Messages").child(messageSenderID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    DatabaseReference removeReference;
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        if (dataSnapshot.exists()) {
                            if (dataSnapshot.getKey().contains(messageReceiverID)) {
                                removeReference = dataSnapshot.getRef();
                                removeReference.removeValue();
                                onBackPressed();
                            }
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    void setRead() {
        RootRef.child("Messages").child(messageSenderID).child(messageReceiverID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {

                    Log.e("child", "onDataChange: " + snapshot1);
                    if (snapshot1.exists()) {
                        if (snapshot1.child("status").exists()) {
                            Log.e("child", "onDataChange: ");

                            if (snapshot1.child("status").getValue().toString().contains("unread") && snapshot1.child("to").getValue().toString().contains(messageSenderID)) {

                                DatabaseReference messageRef = snapshot1.getRef();
                                messageRef.child("status").setValue("read");
                                Log.e("messageRef", "onDataChange: " + messageRef);

                            }
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void PressBack(View view) {
        finish();
    }

    // gallery chooser
    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
        ) {
            mImageUri = data.getData();
            if (mUploadTask != null && mUploadTask.isInProgress()) {
                Toast.makeText(this, "Already uploading image...", Toast.LENGTH_SHORT).show();
            } else {
                uploadFile();
                Log.e("imgPath", "onActivityResult: "+mImageUri );
            }
//            Glide.with(this).load(mImageUri).into(mImageView);
        }
        if (requestCode == REQUEST_READ_EXTERNAL_STORAGE && resultCode == RESULT_OK)
        {
            mImageUri= Uri.fromFile(file);
            if (mUploadTask != null && mUploadTask.isInProgress()) {
                Toast.makeText(this, "Already uploading image...", Toast.LENGTH_SHORT).show();
            } else {
                uploadFile();
                Log.e("imgPath", "onActivityResult: "+mImageUri );
            }
        }
    }




    private void uploadFile() {
        if (mImageUri != null) {
            StorageReference fileReference = mStorageRef.child(messageSenderID).child(messageReceiverID).child(System.currentTimeMillis()
                    + "." + getFileExtension(mImageUri));
            mProgressBar.setVisibility(View.VISIBLE);
            mUploadTask = fileReference.putFile(mImageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    mProgressBar.setProgress(0);
                                    Log.e("onSuccessUploadProgress", "onSuccess: " );
                                    mProgressBar.setVisibility(View.GONE);
                                }
                            }, 500);

                            Task<Uri> urlTask = taskSnapshot.getStorage().getDownloadUrl();
                            while (!urlTask.isSuccessful());
                            Uri downloadUrl = urlTask.getResult();

                            Toast.makeText(getApplicationContext(),"Upload successful",Toast.LENGTH_SHORT).show();

//                            Upload upload = new Upload(mEditTextFileName.getText().toString().trim(),
//                                    downloadUrl.toString());
//                            String uploadId = mDatabaseRef.push().getKey();
//                            mDatabaseRef.child(uploadId).setValue(upload);
                            SendMessage(downloadUrl.toString());
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            mProgressBar.setVisibility(View.GONE);
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            mProgressBar.setProgress((int) progress);
                            Log.e("onSuccessUpload", "onSuccess: "+100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount() );
                        }
                    });
        } else {
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
        }
    }
    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void CameraIntent() throws IOException {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startActForRes();
        } else {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA}, REQUEST_READ_EXTERNAL_STORAGE);
        }
    }

    void startActForRes() throws IOException {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // get path of capturd imgae from created file
        file= createFile();
        Uri output=  FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID +".provider",file);
        Log.e("functionCall", "startActForRes: " );
        intent.putExtra(MediaStore.EXTRA_OUTPUT,output);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_READ_EXTERNAL_STORAGE);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode==REQUEST_READ_EXTERNAL_STORAGE && grantResults.length>0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                try {
                    startActForRes();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void showDialog(View view){
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_select_imag);

        TextView text_camera = (TextView) dialog.findViewById(R.id.camera);
        TextView text_galery = (TextView) dialog.findViewById(R.id.Gallery);

        text_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    CameraIntent();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                dialog.cancel();
            }
        });
        text_galery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
                dialog.cancel();
            }
        });
        dialog.setCancelable(true);
        dialog.show();

    }


    private File createFile() throws IOException {
//         Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File storageDir = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(
                "JPEG_${timeStamp}_", /* prefix */
                ".jpg", /* suffix */
                storageDir /* directory */);
    }
}