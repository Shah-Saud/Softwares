package com.example.progro.Tasks;

public class Tasks_Model {

    String Date,Img,Name,LandType;

    public Tasks_Model() {
    }

    public Tasks_Model(String date, String img, String name, String landType) {
        Date = date;
        Img = img;
        Name = name;
        LandType = landType;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getImg() {
        return Img;
    }

    public void setImg(String img) {
        Img = img;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getLandType() {
        return LandType;
    }

    public void setLandType(String landType) {
        LandType = landType;
    }
}
