package com.example.progro.CropsProtection;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.LoadingDailog;
import com.example.progro.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Pulses_Protection extends AppCompatActivity {
    private ArrayList<Protection_Model> modelList;
    private Context mpContext;
    private DatabaseReference myRef;
    private Protection_Adapter recViewAdpter;
    RecyclerView recyclerView;
    ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pulses_protection);

        btnBack = (ImageView) findViewById(R.id.btnBack);
        showLoading();



        this.recyclerView = (RecyclerView) findViewById(R.id.rec_view_protect);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.recyclerView.setHasFixedSize(true);
        this.myRef = FirebaseDatabase.getInstance().getReference();
        this.modelList = new ArrayList<>();
        ClearAll();
        GetDataFromFirebase();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                Pulses_Protection.this.finish();
            }
        });
    }

    private void GetDataFromFirebase() {
        this.myRef.child("Crops_Protection/Pulses").addValueEventListener(new ValueEventListener() {


            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot datasnapshot) {
                for (DataSnapshot snapshot : datasnapshot.getChildren()) {
                    Protection_Model model = new Protection_Model();
                    model.setName(snapshot.child("Name").getValue().toString());
                    model.setSymptoms(snapshot.child("Symptoms").getValue().toString());
                    model.setCure(snapshot.child("Cure").getValue().toString());
                    model.setImg(snapshot.child("imglink").getValue().toString());
                    Pulses_Protection.this.modelList.add(model);
                }
                Pulses_Protection.this.recViewAdpter = new Protection_Adapter(Pulses_Protection.this.modelList, Pulses_Protection.this.getApplicationContext());
                Pulses_Protection.this.recyclerView.setAdapter(Pulses_Protection.this.recViewAdpter);
                Pulses_Protection.this.recViewAdpter.notifyDataSetChanged();
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
            }
        });
    }

    private void ClearAll() {
        ArrayList<Protection_Model> arrayList = this.modelList;
        if (arrayList != null) {
            arrayList.clear();
            Protection_Adapter pRecViewAdpter = this.recViewAdpter;
            if (pRecViewAdpter != null) {
                pRecViewAdpter.notifyDataSetChanged();
                return;
            }
            return;
        }
        this.modelList = new ArrayList<>();
    }
    public void showLoading(){
        final LoadingDailog loadingDailog = new LoadingDailog(Pulses_Protection.this);
        loadingDailog.startLoading();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDailog.closeLoading();
            }
        } ,5000);
    }
}