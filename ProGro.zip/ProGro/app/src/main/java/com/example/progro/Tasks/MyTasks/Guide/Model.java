package com.example.progro.Tasks.MyTasks.Guide;

public class Model {
    String name,details,date,img;

    public Model() {
    }

    public Model(String name, String details, String date, String img) {
        this.name = name;
        this.details = details;
        this.date = date;
        this.img = img;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


}
