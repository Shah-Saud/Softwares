package com.example.progro.Inventory.Tools;

public class Tools_Model {
    String name,quantity,location,details;

    public Tools_Model() {
    }

    public Tools_Model(String name, String quantity, String location, String details) {

        this.details = details;
        this.location = location;
        this.name = name;
        this.quantity = quantity;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }



    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }


}
