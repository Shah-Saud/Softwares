package com.example.progro.Registration.OtpScreen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.progro.R;
import com.example.progro.Registration.forgetPassword.ForgetActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class OtpActivity extends AppCompatActivity implements View.OnClickListener {

    String name,email,password,contact;
    String mobile;
    String status;
    View progbr;
    private static final String TAG = "OtpActivity";

    SharedPreferences spUser;
    SharedPreferences.Editor spEdit;
    private FirebaseAuth mAuth;
    Button verify_btn;
    private String mVerificationId;
    OtpView otpView;
    TextView resendCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        progbr = (View) findViewById(R.id.progress_Bar);

//         contact=SharedPrefence.read(SharedPrefence.phone,"");
        verify_btn=(Button)findViewById(R.id.verification_button);
        otpView=(OtpView)findViewById(R.id.opt_customview);
        resendCode=(TextView)findViewById(R.id.resendCode);

        mAuth = FirebaseAuth.getInstance();


        Intent intent = getIntent();
        mobile = intent.getStringExtra("contact");
        if(!TextUtils.isEmpty(mobile))
        {
            Log.v("numberOtp",mobile);
            sendVerificationCode(mobile);
        }

        resendCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendVerificationCode(mobile);
            }
        });

        verify_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code=otpView.getOTP().toString().trim();
                if (code.isEmpty() || code.length() < 6) {
                    Toast.makeText(OtpActivity.this,"Enter valid code", Toast.LENGTH_SHORT).show();
                    return;
                }

                verifyVerificationCode(code);
            }
        });



    }



    private void sendVerificationCode(String mobile) {
//        PhoneAuthProvider.getInstance().verifyPhoneNumber(
//                mobile,
//                60,
//                TimeUnit.SECONDS,
//                TaskExecutors.MAIN_THREAD,
//                mCallbacks);

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(mobile)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                        .build();

        PhoneAuthProvider.verifyPhoneNumber(options);
        progbr.setVisibility(View.VISIBLE);
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            //Getting the code sent by SMS
            String code = phoneAuthCredential.getSmsCode();
            Log.e("oath", "onVerificationCompleted: "+phoneAuthCredential );

            //sometime the code is not detected automatically
            //in this case the code will be null
            //so user has to manually enter the code
            if (code != null) {
                // editTextCode.setText(code);
                //verifying the code
                Log.e("code", "onVerificationCompleted: "+code );
                verifyVerificationCode(code);
            }
            else
            {
                Toast.makeText(OtpActivity.this, "Error", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Toast.makeText(OtpActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            progbr.setVisibility(View.GONE);
        }

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            mVerificationId = s;
            progbr.setVisibility(View.GONE);
            Toast.makeText(OtpActivity.this, "Code Sent", Toast.LENGTH_SHORT).show();
            //mResendToken = forceResendingToken;
        }
    };


    private void verifyVerificationCode(String code) {
        //creating the credential
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, code);
        Log.v("verifyCode","yes");
        //signing the user
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //verification successful we will start the profile activity
                            Intent intent = new Intent(OtpActivity.this, ForgetActivity.class);
                            Log.v("onSuccess","otp success");
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            intent.putExtra("contact",mobile);
                            progbr.setVisibility(View.GONE);
                            startActivity(intent);
                            overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                            finish();

                        } else {
                            Log.v("onSuccess","otp fails");
                            //verification unsuccessful.. display an error message

                        }
                    }
                });
    }


    public void setKeyboardView(View v){

    }

    @Override
    public void onClick(View v) {

    }

}