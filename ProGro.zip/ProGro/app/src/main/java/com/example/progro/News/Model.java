package com.example.progro.News;

public class Model {

    String Header,Img,Source;

    public Model() {
    }


    public Model(String header, String img, String source) {
        Header = header;
        Img = img;
        Source = source;
    }

    public String getHeader() {
        return Header;
    }

    public void setHeader(String header) {
        Header = header;
    }

    public String getImg() {
        return Img;
    }

    public void setImg(String img) {
        Img = img;
    }

    public String getSource() {
        return Source;
    }

    public void setSource(String source) {
        Source = source;
    }
}
