package com.example.progro.Inventory.Stock;

public class Stock_Model {

    String type,quantity,location,details;

    public Stock_Model() {
    }

    public Stock_Model(String type, String quantity, String location, String details) {
        this.type = type;
        this.quantity = quantity;
        this.location = location;
        this.details = details;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
