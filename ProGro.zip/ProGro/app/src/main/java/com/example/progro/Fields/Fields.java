package com.example.progro.Fields;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.FirebaseDatabase;

import io.paperdb.Paper;

public class Fields extends AppCompatActivity {
    Fields_Adapter myAdapter;
    Fields_AdapterPublic myAdapterPublic;
    RecyclerView recView,recViewPublic;
    FloatingActionButton addField;
    String Phone = Paper.book().read("Phone");
    String Province = Paper.book().read("Province");
    String City = Paper.book().read("City");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fields);
        addField = (FloatingActionButton) findViewById(R.id.addField);


        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rec_view_fields_list);
        recView = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        Fields_Adapter myAdpter1 = new Fields_Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance()
                .getReference().child("Fields/"+Province+"/"+City+"/"+Phone), Fields_Model.class).build());

        myAdapter = myAdpter1;
        recView.setAdapter(myAdpter1);

        RecyclerView recyclerViewPublic = (RecyclerView) findViewById(R.id.rec_view_public_list);
        recViewPublic = recyclerViewPublic;
        recyclerViewPublic.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        Fields_AdapterPublic myAdapter2 = new Fields_AdapterPublic(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance().getReference().child("Fields/"+Province+"/"+City+"/PublicData"), Fields_Model.class).build());
        myAdapterPublic = myAdapter2;
        recViewPublic.setAdapter(myAdapter2);


        addField.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Fields.this, Add_Fields.class));

            }
        });
    }


    public void onStart() {
        super.onStart();
        myAdapter.startListening();
        myAdapterPublic.startListening();
    }


    @Override
    public void onStop() {
        super.onStop();
        myAdapter.stopListening();
        myAdapterPublic.stopListening();
    }

}