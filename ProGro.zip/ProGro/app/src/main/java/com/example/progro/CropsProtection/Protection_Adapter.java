package com.example.progro.CropsProtection;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.example.progro.R;

import java.util.ArrayList;

public class Protection_Adapter  extends RecyclerView.Adapter<Protection_Adapter.ViewHolder> {
    private static final String Tag = "RecyclerView";
    private ArrayList<Protection_Model> modelList;
    private Context mpContext;

    public Protection_Adapter(ArrayList<Protection_Model> modelList, Context mpContext) {
        this.modelList = modelList;
        this.mpContext = mpContext;
    }

    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_protection, parent, false));
    }

    @Override
    public void onBindViewHolder( Protection_Adapter.ViewHolder holder, int position) {
        holder.name.setText(this.modelList.get(position).getName());
        holder.symp.setText(this.modelList.get(position).getSymptoms());
        holder.cure.setText(this.modelList.get(position).getCure());
        Glide.with(this.mpContext).load(this.modelList.get(position).getImg()).placeholder(R.drawable.no_img).error(R.drawable.error).transition(DrawableTransitionOptions.withCrossFade()).into(holder.img);

    }

    @Override
    public int getItemCount() {
        return this.modelList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView cure;
        ImageView img;
        TextView name;
        TextView symp;

        public ViewHolder(View itemView) {
            super(itemView);
            this.name = (TextView) itemView.findViewById(R.id.NameText);
            this.img = (ImageView) itemView.findViewById(R.id.LifeImg);
            this.symp = (TextView) itemView.findViewById(R.id.SymText);
            this.cure = (TextView) itemView.findViewById(R.id.CureText);
        }
    }
}
