package com.example.progro.Tutorials.Videos;

public class Model_Videos {

    String Title,VideoLink;

    public Model_Videos() {
    }

    public Model_Videos(String title, String videoLink) {
        Title = title;
        VideoLink = videoLink;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getVideoLink() {
        return VideoLink;
    }

    public void setVideoLink(String videoLink) {
        VideoLink = videoLink;
    }
}
