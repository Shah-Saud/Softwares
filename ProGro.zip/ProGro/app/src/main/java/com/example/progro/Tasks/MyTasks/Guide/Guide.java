package com.example.progro.Tasks.MyTasks.Guide;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.R;
import com.example.progro.Tasks.MyTasks.My_Tasks;
import com.example.progro.Tasks.MyTasks.Mytasks_Adapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import io.paperdb.Paper;

public class Guide extends AppCompatActivity {
    Adapter myAdpter;
    RecyclerView recview;

    public  String Province = Paper.book().read("Province"), City = Paper.book().read("City");
    String path="Tasks/NewTasks/"+Province+"/"+City+"/"+ Mytasks_Adapter.taskId +"/Guide";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);


        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rec_view_guide);
        recview = recyclerView;

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Adapter myAdpter1 = new Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance()
                .getReference().child(path), Model.class).build());
        myAdpter = myAdpter1;
        recview.setAdapter(myAdpter1);
    }


    public void onStart() {
        super.onStart();
        myAdpter.startListening();
    }


    @Override
    public void onStop() {
        super.onStop();
        myAdpter.stopListening();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        this.finish();
        startActivity(new Intent(getApplicationContext(), My_Tasks.class));
    }
}