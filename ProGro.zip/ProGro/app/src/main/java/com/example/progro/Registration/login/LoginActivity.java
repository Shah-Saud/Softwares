package com.example.progro.Registration.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.progro.MainActivity;
import com.example.progro.R;
import com.example.progro.Registration.SharePrefence;
import com.example.progro.Registration.enterPhone.EnterPhone;
import com.example.progro.Registration.signup.SignupActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hbb20.CountryCodePicker;

import io.paperdb.Paper;

public class LoginActivity extends AppCompatActivity {
    Context mContext;
    CountryCodePicker ccp;
    RelativeLayout whiteLayout;
    EditText editTextwPhn,editTextwPass;
    Button btnLogin;
    public String  phoneNumber,Province,City;
    View progressBar;
    DatabaseReference dbRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mContext= this;
        SharePrefence.init(mContext);
        whiteLayout= findViewById(R.id.log_rel_white);
        editTextwPhn= findViewById(R.id.edit_text_num);
        editTextwPass= findViewById(R.id.log_pass);
        btnLogin= findViewById(R.id.btn_sign_in);
        ccp = findViewById(R.id.ccl);
        progressBar = (View) findViewById(R.id.progress_Bar);
        // set animation
        Animation myanim= AnimationUtils.loadAnimation(this, R.anim.bounce);
        whiteLayout.setAnimation(myanim);

        dbRef= FirebaseDatabase.getInstance().getReference("Users");
        initSetUp();
    }

    private void initSetUp() {

        ccp.registerCarrierNumberEditText(editTextwPhn);

        ccp.setPhoneNumberValidityChangeListener(new CountryCodePicker.PhoneNumberValidityChangeListener() {
            @Override
            public void onValidityChanged(boolean isValidNumber) {

            }
        });
        editTextwPhn.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keycode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keycode == KeyEvent.KEYCODE_ENTER) {
                    ValidatePhone();


                }
                return false;
            }
        });

    }
    private void ValidatePhone() {
        if (ccp.isValidFullNumber()) {

            phoneNumber=ccp.getFullNumberWithPlus();

            SharePrefence.write(SharePrefence.phoneNumber,phoneNumber);

            Log.e("SignUp", "ValidatePhone: "+phoneNumber );


        }
        else {
            Toast.makeText(mContext, "Invalid Number", Toast.LENGTH_SHORT).show();
        }


    }


    public void signInBtnClick(View view) {
        String password=editTextwPass.getText().toString();
        ValidatePhone();

        if(!TextUtils.isEmpty(phoneNumber) )
        {
            if(!TextUtils.isEmpty(password) ) {
                if(password.length()>6) {
                    progressBar.setVisibility(View.VISIBLE);
                    dbRef.child(phoneNumber).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {

                                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                    if (snapshot1.getKey().contains("password")) {
                                        if (snapshot1.getValue().equals(password)) {
                                            progressBar.setVisibility(View.GONE);

                                            //SharePrefence.write(SharePrefence.IS_LOGGED_IN, true);
                                            Paper.book().write("IS_LOGGED_IN",true);
                                            //SharePrefence.write(SharePrefence.password, password);
                                            Paper.book().write("password",password);

                                            //getting user info for using in app
                                            phoneNumber = snapshot.getKey().toString();
                                            Province = snapshot.child("province").getValue().toString();
                                            City = snapshot.child("city").getValue().toString();

                                            //SharePrefence.write(SharePrefence.phoneNumber, phoneNumber);
                                            Paper.book().write("Phone",phoneNumber);
                                            //SharePrefence.write(SharePrefence.Province, Province);
                                            Paper.book().write("Province", Province);
                                            //SharePrefence.write(SharePrefence.City, City);
                                            Paper.book().write("City",City);
                                            //Log.d("Data: ",Province+" "+City+" "+phoneNumber);







                                            startActivity(new Intent(mContext, MainActivity.class));
                                            overridePendingTransition(R.anim.splash_in, R.anim.splash_out);
                                            finish();
                                        }
                                        else
                                        {
                                            showMessage("Please enter correct Password");
                                            progressBar.setVisibility(View.GONE);
                                        }
                                    }
                                }
                            } else {
                                progressBar.setVisibility(View.GONE);
                                showMessage("Sign Up first");
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
                }
                else
                {
                    showMessage("Password must be greater than Six digits !");
                }
            }
            else
            {
                showMessage("Password cannot be empty !");
            }
        }
        else
        {
            showMessage("Phone number cannot be empty !");
        }



    }

    void showMessage(String message)
    {
        Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
    }
    public void openSignup(View view) {
        startActivity(new Intent(mContext, SignupActivity.class));
        finish();
    }


    public void OpenForgetActivity(View view) {

        startActivity(new Intent(this, EnterPhone.class));
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }


    @Override
    protected void onStart() {
        super.onStart();
        if((Boolean)Paper.book().contains("IS_LOGGED_IN"))
        {

            startActivity(new Intent(mContext, MainActivity.class));
            finish();
        }

    }
}