package com.example.progro.CropsProtection;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.progro.R;

public class Protection_Menu extends AppCompatActivity {
    CardView CottonProtect,FruitsProtect,MaizeProtect,PulsesProtect,RiceProtect,SugarCaneProtect,VegProtect,WheatProtect;
    ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_protection_menu);



        btnBack = (ImageView) findViewById(R.id.btnBack);
        WheatProtect = (CardView) findViewById(R.id.protect_wheat);
        MaizeProtect = (CardView) findViewById(R.id.protect_maize);
        RiceProtect = (CardView) findViewById(R.id.protect_rice);
        CottonProtect = (CardView) findViewById(R.id.protect_Cotton);
        SugarCaneProtect = (CardView) findViewById(R.id.protect_CaneSeeds);
        PulsesProtect = (CardView) findViewById(R.id.protect_Pulses);
        VegProtect = (CardView) findViewById(R.id.protect_Vegetables);
        FruitsProtect = (CardView) findViewById(R.id.protect_Fruits);



        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                Protection_Menu.this.finish();
            }
        });

       WheatProtect.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Protection_Menu.this.startActivity(new Intent(Protection_Menu.this.getApplicationContext(), Wheat_Protection.class));
            }
        });
       MaizeProtect.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Protection_Menu.this.startActivity(new Intent(Protection_Menu.this.getApplicationContext(), Maize_Protection.class));
            }
        });
        RiceProtect.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Protection_Menu.this.startActivity(new Intent(Protection_Menu.this.getApplicationContext(), Rice_Protection.class));
            }
        });
        CottonProtect.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Protection_Menu.this.startActivity(new Intent(Protection_Menu.this.getApplicationContext(), Cotton_Protection.class));
            }
        });
        SugarCaneProtect.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Protection_Menu.this.startActivity(new Intent(Protection_Menu.this.getApplicationContext(), SugarCane_Protection.class));
            }
        });
        PulsesProtect.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Protection_Menu.this.startActivity(new Intent(Protection_Menu.this.getApplicationContext(), Pulses_Protection.class));
            }
        });
        VegProtect.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Protection_Menu.this.startActivity(new Intent(Protection_Menu.this.getApplicationContext(), Vegetables_Protection.class));
            }
        });
        FruitsProtect.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Protection_Menu.this.startActivity(new Intent(Protection_Menu.this.getApplicationContext(), Fruits_Protection.class));
            }
        });


    }
}