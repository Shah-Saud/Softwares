package com.example.progro.Weather;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.progro.MainActivity;
import com.example.progro.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Weather extends AppCompatActivity implements GPS {
    ImageView iconImg,btnBack;
    public double latitude;
    public double longitude;
    public ImageView ref;
    public RequestQueue requestQueue;
    public TextView tV1;
    public TextView tvCity;
    public TextView tvClouds;
    public TextView tvCountry;
    public TextView tvDescp;
    public TextView tvHumidity;
    public TextView tvPressure;
    public TextView tvRainPrecipitation;
    public TextView tvTemp;
    public TextView tvWind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
//        getSupportActionBar().hide();


        tvCity = (TextView) findViewById(R.id.cityName);
        tvCountry = (TextView) findViewById(R.id.countryName);
        tvTemp = (TextView) findViewById(R.id.temp);
        tvDescp = (TextView) findViewById(R.id.description);
        tvHumidity = (TextView) findViewById(R.id.humidity);
        tvPressure = (TextView) findViewById(R.id.pressure);
        tvWind = (TextView) findViewById(R.id.wind);
        tvClouds = (TextView) findViewById(R.id.cloudprcent);
        tvRainPrecipitation = (TextView) findViewById(R.id.rainprecp);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        tV1 = (TextView) findViewById(R.id.tv1);
        ref = (ImageView) findViewById(R.id.refresh);
        iconImg = (ImageView) findViewById(R.id.iconm);
        btnBack = (ImageView) findViewById(R.id.btnBack);


        ref.setOnClickListener(new View.OnClickListener() {

            @RequiresApi(api = Build.VERSION_CODES.P)
            public void onClick(View v) {
                getLocation();
                getWeather();
                GetRain();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Weather.this, MainActivity.class);
                startActivity(intent);
                Weather.this.finish();

            }
        });


    }

    @SuppressLint("WrongConstant")
    @RequiresApi(api = Build.VERSION_CODES.P)
    public void getLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) !=
                        PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

        } else {
            showLocation();
        }
    }



    @SuppressLint("MissingSuperCall")
    @RequiresApi(api = Build.VERSION_CODES.P)
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
       if(requestCode == 1){
           if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
               showLocation();
           }else{
               Toast.makeText(this,"Permission not granted",Toast.LENGTH_SHORT);

           }
       }
    }



    @RequiresApi(api = Build.VERSION_CODES.P)
    private void showLocation() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

        } else {
            Toast.makeText(this, "Enable GPS",Toast.LENGTH_LONG);
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        }
    }


    @Override
    public void onLocationChanged(Location location) {
        this.longitude = location.getLongitude();
        this.latitude = location.getLatitude();
    }

    @Override
    public void onProviderDisabled(String provider) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onStatusChanged(String provider, int Status, Bundle extra) {
    }

    @Override
    public void onGpsStatusChanged(int event) {
    }





    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onStart() {
        super.onStart();
        getLocation();
    }

    private void getWeather() {
        this.requestQueue.add(new JsonObjectRequest(0, "https://api.openweathermap.org/data/2.5/weather?lat=" + this.latitude + "&lon=" + this.longitude + "&units=metric&appid=4b2d17aed38c7bd7dbcd3772b9e2d2d8", null, new Response.Listener<JSONObject>() {
           

            public void onResponse(JSONObject response) {
                try {
                    Long dt = Long.valueOf((long) response.getInt("dt"));
                    Log.d("date", String.valueOf(dt));
                    String dateText = new SimpleDateFormat("dd/MM/yy").format(new Date(dt.longValue() * 1000));
                    TextView textView = Weather.this.tV1;
                    textView.setText("Date: " + dateText);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                try {
                    String city = response.getString("name");
                    String country = response.getJSONObject(NotificationCompat.CATEGORY_SYSTEM).getString("country");
                    Weather.this.tvCity.clearComposingText();
                    Weather.this.tvCity.setText(city);
                    Weather.this.tvCountry.setText(country);
                    Log.d("info", city + ", " + country);
                } catch (JSONException e2) {
                    e2.printStackTrace();
                }
                try {
                    JSONObject jsonObject = response.getJSONArray("weather").getJSONObject(0);
                    jsonObject.getString("main");
                    String description = jsonObject.getString("description");
                    Weather.this.IconChanger(jsonObject.getString("icon"));
                    Weather.this.tvDescp.setText(description);
                } catch (JSONException e3) {
                    e3.printStackTrace();
                }
                try {
                    JSONObject main = response.getJSONObject("main");
                    TextView textView2 = Weather.this.tvTemp;
                    textView2.setText(((int) main.getDouble("temp")) + " °C");
                    TextView textView3 = Weather.this.tvHumidity;
                    textView3.setText(((int) main.getDouble("humidity")) + " %");
                    TextView textView4 = Weather.this.tvPressure;
                    textView4.setText(((int) main.getDouble("pressure")) + " hpa");
                } catch (JSONException e4) {
                    e4.printStackTrace();
                }
                try {
                    int speed = (((int) response.getJSONObject("wind").getDouble("speed")) * 18) / 5;
                    TextView textView5 = Weather.this.tvWind;
                    textView5.setText(speed + " km/h");
                } catch (JSONException e5) {
                    e5.printStackTrace();
                }
                try {
                    int cloud = response.getJSONObject("clouds").getInt("all");
                    TextView textView6 = Weather.this.tvClouds;
                    textView6.setText(cloud + "%");
                } catch (JSONException e6) {
                    e6.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {


            @Override // com.android.volley.Response.ErrorListener
            public void onErrorResponse(VolleyError error) {
                Log.d("Loc", "Dindt Get Data");
            }
        }));
    }


    private void GetRain() {

        this.requestQueue.add(new JsonObjectRequest(0, "https://api.openweathermap.org/data/2.5/onecall?lat=" + this.latitude + "&lon=" + this.longitude + "&exclude=hourly,daily,alerts&units=metric&appid=4b2d17aed38c7bd7dbcd3772b9e2d2d8", null, new Response.Listener<JSONObject>() {


            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("minutely");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        int rain = jsonArray.getJSONObject(i).getInt("precipitation");
                        TextView textView = Weather.this.tvRainPrecipitation;
                        textView.setText(rain + "%");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {


            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Loc", "Dindt Get Data");
            }
        }));
    }

    private void IconChanger(String icon) {

        char c;
        switch (icon.hashCode()) {
            case 47747:
                if (icon.equals("01d")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case 47757:
                if (icon.equals("01n")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case 47778:
                if (icon.equals("02d")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case 47788:
                if (icon.equals("02n")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case 47809:
                if (icon.equals("03d")) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            case 47819:
                if (icon.equals("03n")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case 47840:
                if (icon.equals("04d")) {
                    c = 6;
                    break;
                }
                c = 65535;
                break;
            case 47850:
                if (icon.equals("04n")) {
                    c = 7;
                    break;
                }
                c = 65535;
                break;
            case 47995:
                if (icon.equals("09d")) {
                    c = '\b';
                    break;
                }
                c = 65535;
                break;
            case 48005:
                if (icon.equals("09n")) {
                    c = '\t';
                    break;
                }
                c = 65535;
                break;
            case 48677:
                if (icon.equals("10d")) {
                    c = '\n';
                    break;
                }
                c = 65535;
                break;
            case 48687:
                if (icon.equals("10n")) {
                    c = 11;
                    break;
                }
                c = 65535;
                break;
            case 48708:
                if (icon.equals("11d")) {
                    c = '\f';
                    break;
                }
                c = 65535;
                break;
            case 48718:
                if (icon.equals("11n")) {
                    c = '\r';
                    break;
                }
                c = 65535;
                break;
            case 48770:
                if (icon.equals("13d")) {
                    c = 14;
                    break;
                }
                c = 65535;
                break;
            case 48780:
                if (icon.equals("13n")) {
                    c = 15;
                    break;
                }
                c = 65535;
                break;
            case 52521:
                if (icon.equals("50d")) {
                    c = 16;
                    break;
                }
                c = 65535;
                break;
            case 52531:
                if (icon.equals("50n")) {
                    c = 17;
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                this.iconImg.setImageResource(R.drawable.sun);
                return;
            case 1:
                this.iconImg.setImageResource(R.drawable.clear_night);
                return;
            case 2:
                this.iconImg.setImageResource(R.drawable.few_cloud_day_night);
                return;
            case 3:
                this.iconImg.setImageResource(R.drawable.few_cloud_day_night);
                return;
            case 4:
                this.iconImg.setImageResource(R.drawable.sc_clouds_day);
                return;
            case 5:
                this.iconImg.setImageResource(R.drawable.scattered_clouds_night);
                return;
            case 6:
                this.iconImg.setImageResource(R.drawable.broken_clouds_day);
                return;
            case 7:
                this.iconImg.setImageResource(R.drawable.nightbroken);
                return;
            case '\b':
                this.iconImg.setImageResource(R.drawable.shower_rain_day);
                return;
            case '\t':
                this.iconImg.setImageResource(R.drawable.shower_rain_night);
                return;
            case '\n':
                this.iconImg.setImageResource(R.drawable.rndn);
                return;
            case 11:
                this.iconImg.setImageResource(R.drawable.rndn);
                return;
            case '\f':
                this.iconImg.setImageResource(R.drawable.thunder_storm_dn);
                return;
            case '\r':
                this.iconImg.setImageResource(R.drawable.thunder_storm_dn);
                return;
            case 14:
                this.iconImg.setImageResource(R.drawable.snow);
                return;
            case 15:
                this.iconImg.setImageResource(R.drawable.snow);
                return;
            case 16:
                this.iconImg.setImageResource(R.drawable.mist);
                return;
            case 17:
                this.iconImg.setImageResource(R.drawable.mist);
                return;
            default:
                return;
        }
    }

    }

