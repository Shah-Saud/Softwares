package com.example.progro.Inventory.Stock;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.progro.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

import io.paperdb.Paper;

public class Inventory_Stock_Addrec extends AppCompatActivity {
    EditText type,quantity,location,details;
    Button btnAdd,btnBack;

    //getting phonenumber of user
    String Phone = Paper.book().read("Phone");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_stock_addrec);


        type = (EditText) findViewById(R.id.txtType);
        location = (EditText) findViewById(R.id.txtLocation);
        quantity = (EditText) findViewById(R.id.txtQuantity);
        details = (EditText) findViewById(R.id.txtDetails);

        btnAdd = (Button)findViewById(R.id.btnAdd);
        btnBack = (Button)findViewById(R.id.btnBack);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(details.getText().toString().trim().length()<=0 &&
                        quantity.getText().toString().trim().length() <=0 &&
                        location.getText().toString().trim().length()<=0 &&
                        type.getText().toString().trim().length()<=0){
                    Toast.makeText(Inventory_Stock_Addrec.this, "Please fill the required fields", Toast.LENGTH_SHORT).show();
                }else{
                    insetData();
                    clearAll();
                }


            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();


            }
        });
    }

    private void insetData(){
        Map<String,Object> map = new HashMap<>();


        map.put("type",type.getText().toString());
        map.put("quantity",quantity.getText().toString());
        map.put("location",location.getText().toString());
        map.put("details",details.getText().toString());


        FirebaseDatabase.getInstance().getReference().child("Inventory/"+Phone+"/Stock").push()
                .setValue(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(Inventory_Stock_Addrec.this, "Record Added", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                Toast.makeText(Inventory_Stock_Addrec.this, "Error Occurred", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void clearAll(){

        location.setText("");
        quantity.setText("");
        type.setText("");
        details.setText("");
    }
}