package com.example.progro.Tasks.MyTasks;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.progro.R;
import com.example.progro.Tasks.MyTasks.Guide.Guide;
import com.example.progro.Tasks.Tasks_Model;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.NotNull;

import de.hdodenhof.circleimageview.CircleImageView;
import io.paperdb.Paper;

public class Mytasks_Adapter extends FirebaseRecyclerAdapter<Tasks_Model,Mytasks_Adapter.myViewHolder> {
    String id;
    public static String taskId;
    String Phone = Paper.book().read("Phone");
    String Province = Paper.book().read("Province");
    String City = Paper.book().read("City");




    public Mytasks_Adapter(@NonNull @NotNull FirebaseRecyclerOptions<Tasks_Model> options) {
        super(options);


    }



    @Override
    protected void onBindViewHolder(@NonNull @NotNull myViewHolder holder, int position, @NonNull @NotNull Tasks_Model model) {
        holder.Name.setText(model.getName());
        holder.Date.setText(model.getDate());


        Glide.with(holder.img.getContext())
                .load(model.getImg())
                .placeholder(R.drawable.loading)
                .circleCrop()
                .error(R.drawable.error)
                .into(holder.img);


        holder.btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(holder.Name.getContext());
                    builder.setTitle("Are you sure?");
                    builder.setMessage("Remove task cannot be restored.");

                    builder.setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

    FirebaseDatabase.getInstance().getReference().child("Tasks/FollowedTasks/" +Province + "/" +City+"/"+ Phone)
                                    .child(getRef(position).getKey()).removeValue();
                            Toast.makeText(holder.Name.getContext(), "Removed", Toast.LENGTH_SHORT).show();

                        }
                    });

                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(holder.Name.getContext(), "Canceled", Toast.LENGTH_SHORT).show();
                        }
                    });

                    builder.show();
                }

        });

        holder.btnGuide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                taskId = getRef(position).getKey();
                Intent intent = new Intent(holder.Name.getContext(), Guide.class);

                holder.Name.getContext().startActivity(intent);





            }
        });
    }

    @NonNull
    @NotNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_tasks_single_row,parent,false);
        return new Mytasks_Adapter.myViewHolder(view);
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView Name,Date;
        CircleImageView img;
        Button btnGuide,btnRemove;


        public myViewHolder(View itemView) {
            super(itemView);
            Name = (TextView) itemView.findViewById(R.id.txt_myTaskName);
            Date=(TextView) itemView.findViewById(R.id.txt_myTaskDate);
            img = (CircleImageView) itemView.findViewById(R.id.myTaskImg);

            btnGuide = (Button) itemView.findViewById(R.id.btnGuide);
            btnRemove = (Button) itemView.findViewById(R.id.btnRemove);
        }
    }
}
