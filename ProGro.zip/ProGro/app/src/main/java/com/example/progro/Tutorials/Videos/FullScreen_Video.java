package com.example.progro.Tutorials.Videos;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.progro.R;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

public class FullScreen_Video extends AppCompatActivity {
    private PlayerView playerView;
    private SimpleExoPlayer player;
    TextView vtTitle;
    private String title, url;
    private boolean fullScreen = false, playwhenready=false;
    private int currentWindow =0;
    private long playbackPosition = 0;
    private ImageView fullScreen_button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_screen_video);

        playerView = findViewById(R.id.video_link_full_screen);
        vtTitle = findViewById(R.id.video_title_full_screen);
        fullScreen_button = playerView.findViewById(R.id.exoplayer_fullscreen_icon);

        Intent intent = getIntent();
        url = intent.getExtras().getString("ur");
        title = intent.getExtras().getString("tl");

        vtTitle.setText(title);
        FullScreen();


        fullScreen_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //FullScreen();
                finish();
            }
        });
    }

    private void FullScreen() {
        if(fullScreen){

            fullScreen_button.setImageDrawable(ContextCompat.getDrawable(FullScreen_Video.this,R.drawable.ic_fullscreen_expand));

            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);

            if(getSupportActionBar() != null){
                getSupportActionBar().show();
            }

            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) playerView.getLayoutParams();
            params.width = params.MATCH_PARENT;
            params.height = (int) (200 * getResources().getDisplayMetrics().density);
            playerView.setLayoutParams(params);
            fullScreen=false;

        }else {

            fullScreen_button.setImageDrawable(ContextCompat.getDrawable(FullScreen_Video.this,R.drawable.ic_fullscreen_shrink));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    |View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            if(getSupportActionBar() != null){
                getSupportActionBar().hide();
            }


            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) playerView.getLayoutParams();
            params.width = params.MATCH_PARENT;
            params.height = params.MATCH_PARENT;
            playerView.setLayoutParams(params);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            fullScreen=true;
        }
    }

    private MediaSource buildMediaSource(Uri uri) {
        DefaultHttpDataSourceFactory dataSourceFactory = new DefaultHttpDataSourceFactory("Videos");
        return new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(uri);
    }

    private void setPlayer() {

        player =  new com.google.android.exoplayer2.SimpleExoPlayer.Builder(this).build();

        playerView.setPlayer(player);
        Uri uri = Uri.parse(url);
        MediaSource mediaSource = buildMediaSource(uri);
        player.setPlayWhenReady(playwhenready);
        player.seekTo(currentWindow,playbackPosition);
        player.prepare(mediaSource,false,false);
    }

    @Override
    protected void onStart() {
        super.onStart();

        if(Util.SDK_INT >= 26){
            setPlayer();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(Util.SDK_INT >= 26 || player==null){
            //setPlayer();

        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(Util.SDK_INT >26){
            releasePlayer();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(Util.SDK_INT >= 26){
            releasePlayer();
        }
    }

    private void releasePlayer() {
        if(player!=null){
            playwhenready = player.getPlayWhenReady();
            playbackPosition = player.getContentPosition();
            currentWindow = player.getCurrentWindowIndex();
            player = null;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        player.stop();
        releasePlayer();

        final Intent intent = new Intent();
        setResult(RESULT_OK,intent);
        finish();
    }
}