package com.example.progro.Fields;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.progro.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.travijuu.numberpicker.library.NumberPicker;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

import io.paperdb.Paper;

public class Add_Fields extends AppCompatActivity {
    String [] landTypes= {"Silty","Sandy","Clayey","Loamy","Calcareous","Clayey and Silty","Clayey and Sandy","Loamy and Silty"};
    EditText fieldName,crop,year,fertilizers,yield;
    Button Save,Back;
    Spinner landType;
    NumberPicker fieldSize,yieldPicker;
    ArrayAdapter<String> adapterLand;
    NumberPicker numberPicker;
    String selectedLand,Status;
    DatePicker datePicker;
    RadioButton radioPrivate,radioPublic;
    String Phone = Paper.book().read("Phone");
    String Province = Paper.book().read("Province");
    String City = Paper.book().read("City");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_fields);

        fieldName = (EditText) findViewById(R.id.txtName);
        landType = (Spinner) findViewById(R.id.spinnerLand);
        crop = (EditText) findViewById(R.id.txtCrop);
        fertilizers = (EditText) findViewById(R.id.txtFertilizer);
        datePicker = (DatePicker) findViewById(R.id.datePicker);
        Save = (Button) findViewById(R.id.btnAdd);
        Back = (Button) findViewById(R.id.btnBack);
        radioPrivate =(RadioButton) findViewById(R.id.radioPrivate);
        radioPublic = (RadioButton) findViewById(R.id.radioPublic);



        // field size
        numberPicker = (NumberPicker) findViewById(R.id.fieldSize_picker);
        numberPicker.setMax(999999);
        numberPicker.setMin(5);
        numberPicker.setUnit(1);
        numberPicker.setValue(10);

        //Number picker for yield
        yieldPicker = (NumberPicker) findViewById(R.id.Yield_picker);
        yieldPicker.setMax(999999);
        yieldPicker.setMin(5);
        yieldPicker.setUnit(5);
        yieldPicker.setValue(10);



        //setting date picker
        datePicker = findViewById(R.id.datePicker);
        datePicker.findViewById(getResources().getIdentifier("day","id","android")).setVisibility(View.GONE);

        LoadLandTypes();


        //picking selected value of land type
        landType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedLand = landType.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //Saving Records of Fields in Database
        Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                if(fieldName.getText().toString().isEmpty() ||
                        crop.getText().toString().isEmpty() ||
                        fertilizers.getText().toString().isEmpty())
                {

                    Toast.makeText(Add_Fields.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
                }else {

                    getValue();
                }

            }
        });

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Back button
            }
        });

    }

    private void LoadLandTypes() {

        adapterLand = new ArrayAdapter<String>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, landTypes);
        landType.setAdapter(adapterLand);
    }

    public void getValue(){

        if(radioPublic.isChecked()){
            Status="public";
        }else {
            Status="private";
        }
        String FieldName,FieldSize,LandType,Crop,Year,Fertilizers,Yield,status,phone;


        FieldName = fieldName.getText().toString();
        FieldSize = String.valueOf(numberPicker.getValue());
        LandType = selectedLand;
        Crop = crop.getText().toString();
        Year = datePicker.getMonth()+","+datePicker.getYear();
        Fertilizers = fertilizers.getText().toString();
        Yield = String.valueOf(yieldPicker.getValue());
        status=Status;
        phone=Phone;




        DatabaseReference ref=FirebaseDatabase.getInstance().getReference()
                .child("Fields")
                .child(Province).child(City);

        String key=ref.child("PublicData").push().getKey();
        Fields_Model model = new Fields_Model(Crop,Fertilizers, FieldName, FieldSize, LandType, status, Year, Yield,phone,key);



        Map<String, Object> updates = new HashMap<>();
        updates.put(Phone+"/"+key, model);
        updates.put("PublicData/"+key, model);


        if(Status.equals("public")){
            ref.updateChildren(updates).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull @NotNull Task<Void> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(Add_Fields.this, "Data is Added Successfully", Toast.LENGTH_SHORT).show();
                        ClearFields();
                    }else {
                        Toast.makeText(Add_Fields.this, "Data is not Added try again", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else {
            ref.child(Phone).child(key).setValue(model).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull @NotNull Task<Void> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(Add_Fields.this, "Data is Added Successfully", Toast.LENGTH_SHORT).show();
                        ClearFields();
                    }else {
                        Toast.makeText(Add_Fields.this, "Data is not Added try again", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull @NotNull Exception e) {
                    Toast.makeText(Add_Fields.this, "Error", Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

    private void ClearFields() {
        fieldName.setText("");
        fertilizers.setText("");
        crop.setText("");
    }
}