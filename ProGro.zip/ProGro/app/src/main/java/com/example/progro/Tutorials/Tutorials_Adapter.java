package com.example.progro.Tutorials;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.progro.R;
import com.example.progro.Tutorials.Videos.Videos;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import org.jetbrains.annotations.NotNull;

public class Tutorials_Adapter extends FirebaseRecyclerAdapter<Model_Tutorials,Tutorials_Adapter.myViewHolder> {
 public static String Cat_name;
 Context context;

    public Tutorials_Adapter(@NonNull @NotNull FirebaseRecyclerOptions<Model_Tutorials> options, Context applicationContext) {
        super(options);
        this.context = applicationContext;
    }

    @Override
    protected void onBindViewHolder(@NonNull @NotNull myViewHolder holder, int position, @NonNull @NotNull Model_Tutorials model) {
        holder.name.setText(model.getName());

        Glide.with(holder.img.getContext())
                .load(model.getImg())
                .placeholder(R.drawable.loading)

                .error(R.drawable.error)
                .into(holder.img);


        holder.videosBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cat_name = model.getName();
                Intent intent = new Intent(context, Videos.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

            }
        });
    }

    @NonNull
    @NotNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.tutorials_cat_singlerow,parent,false);
        return new Tutorials_Adapter.myViewHolder(view);
    }

    class myViewHolder extends RecyclerView.ViewHolder {

        TextView name;
        ImageView img;
        RelativeLayout videosBtn;


        public myViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.txt_name);
            img = (ImageView) itemView.findViewById(R.id.img1);
            videosBtn = (RelativeLayout) itemView.findViewById(R.id.btnVideos);


        }
    }
}
