package com.example.progro.Registration;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class SharePrefence {
    public static final String NAME = "name";
    public static final String PROFILE_PIC = "profile_pic";
    public static final String USER_DETAIL = "user_detail";
    public static final String IS_LOGGED_IN = "is_logged_in";
    public static SharedPreferences mSharedPref;
    public static final String phoneNumber="phoneNumber";

    public static String email="email";
    public static String password="password";

    public SharePrefence()
    {

    }

    public static void init(Context context)
    {
        if(mSharedPref == null)
            mSharedPref = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
    }

    public static String read(String key, String defValue) {
        return mSharedPref.getString(key, defValue);
    }

    public static void write(String key, String value) {
        SharedPreferences.Editor prefsEditor = mSharedPref.edit();
        prefsEditor.putString(key, value);
        prefsEditor.commit();
    }

    public static boolean read(String key, boolean defValue) {
        return mSharedPref.getBoolean(key, defValue);
    }

    public static void write(String key, boolean value) {
        SharedPreferences.Editor prefsEditor = mSharedPref.edit();
        prefsEditor.putBoolean(key, value);
        prefsEditor.commit();
    }


    public static Long read(String key, long defValue) {
        return mSharedPref.getLong(key, defValue);
    }

    public static void write(String key, long value) {
        SharedPreferences.Editor prefsEditor = mSharedPref.edit();
        prefsEditor.putLong(key, value).apply();
    }


}