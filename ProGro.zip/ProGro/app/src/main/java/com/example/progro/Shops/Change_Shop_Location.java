package com.example.progro.Shops;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.progro.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import io.paperdb.Paper;

public class Change_Shop_Location extends AppCompatActivity {
    Button btnUpdate,btnBack;
    Spinner spinnerProv,spinnerCity;
    DatabaseReference dbrefProve,dbrefCity;

    ValueEventListener listener;
    ArrayList<String> list1,list2;
    ArrayAdapter<String> adapter1,adapter2;
    String Province;
    public  String province= Paper.book().read("Province"),city=Paper.book().read("City");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_shop_location);

        btnUpdate = (Button) findViewById(R.id.btnUpdate);
        btnBack = (Button) findViewById(R.id.btnBack);
        spinnerProv = (Spinner) findViewById(R.id.spinnerProv);
        spinnerCity = (Spinner) findViewById(R.id.spinnerCity);
        dbrefProve = FirebaseDatabase.getInstance().getReference("Shops");


        list1=new ArrayList<String>();
        adapter1=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,list1);
        spinnerProv.setAdapter(adapter1);

        list2=new ArrayList<String>();
        adapter2=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,list2);
        spinnerCity.setAdapter(adapter2);






        fetchProvData();


        spinnerProv.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Province = spinnerProv.getSelectedItem().toString();

                dbrefCity = FirebaseDatabase.getInstance().getReference("Shops/"+Province);

                fetchCityData();

            }



            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });










        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               province = spinnerProv.getSelectedItem().toString();
               city = spinnerCity.getSelectedItem().toString();



                startActivity(new Intent(getApplicationContext(), Shops.class));
            }
        });


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });





    }



    public void fetchProvData(){
        listener= dbrefProve.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                for(DataSnapshot mydata : snapshot.getChildren())
                    list1.add(mydata.getKey().toString());
                adapter1.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


    }


    private void fetchCityData() {
        list2.clear();
        listener= dbrefCity.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                for(DataSnapshot mydata : snapshot.getChildren())
                    list2.add(mydata.getKey().toString());
                adapter2.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }

}