package com.example.progro.CropsVarity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class Variety_Adapter extends FirebaseRecyclerAdapter<Variety_Model, Variety_Adapter.myVholder> {
    public Variety_Adapter(FirebaseRecyclerOptions options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(Variety_Adapter.myVholder holder, int position,  Variety_Model model) {
        TextView textView = holder.Name;
        textView.setText("نام: " + model.getName());
        TextView textView2 = holder.P_yeild;
        textView2.setText("ممکنہ پیداوار: " + model.getPotentialYield());
        TextView textView3 = holder.year;
        textView3.setText("سال: " + model.getYear());

    }


    @Override
    public myVholder onCreateViewHolder( ViewGroup parent, int viewType) {
        return new myVholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_seeds, parent, false));
    }


    public class myVholder extends RecyclerView.ViewHolder {
        TextView Name;
        TextView P_yeild;
        TextView year;

        public myVholder(View itemView) {
            super(itemView);
            this.Name = (TextView) itemView.findViewById(R.id.kindText);
            this.P_yeild = (TextView) itemView.findViewById(R.id.sowingText);
            this.year = (TextView) itemView.findViewById(R.id.areaText);
        }
    }
}
