package com.example.progro.Inventory.Fertilizers;

public class Fertilizers_Model {

    String name,quantity,location,details;

    public Fertilizers_Model() {
    }

    public Fertilizers_Model(String name, String quantity, String location, String details) {
        this.name = name;
        this.quantity = quantity;
        this.location = location;
        this.details = details;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
