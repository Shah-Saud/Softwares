package com.example.progro;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.interfaces.ItemClickListener;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.progro.Chat.Chat;
import com.example.progro.Fields.Fields;
import com.example.progro.Inventory.Inventory_Menu;
import com.example.progro.News.News;
import com.example.progro.Registration.login.LoginActivity;
import com.example.progro.Shops.Shops;
import com.example.progro.Tasks.Tasks;
import com.example.progro.Tutorials.Tutorials;
import com.example.progro.Weather.Weather;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import io.paperdb.Paper;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    public static String phone="+923409022243"; /*here we will store a user phone number and according to that all the user inventory will be stored in firebase*/
    CardView crops,weather,news,inventory,shops,tasks,videos,fields,chat;
    ImageSlider imageSlider;
    BottomNavigationView bottomNavigationView;
    String Phone = Paper.book().read("Phone");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        getSupportActionBar().hide();


        //slider code
        imageSlider = (ImageSlider) findViewById(R.id.image_slider);
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.btmMenu);

        weather = (CardView) findViewById(R.id.weather);
        crops =  (CardView) findViewById(R.id.crops);
        news = (CardView) findViewById(R.id.news);
        inventory =  (CardView) findViewById(R.id.inventory);
        shops = (CardView) findViewById(R.id.shops);
        tasks = (CardView) findViewById(R.id.task);
        videos = (CardView) findViewById(R.id.tutorials);
        fields = (CardView) findViewById(R.id.farm_mngmnt);
        chat = (CardView) findViewById(R.id.consulting);

        //Slider Code

        ArrayList<SlideModel> images = new ArrayList<>();
        images.add(new SlideModel("https://akhbarnama.com/wp-content/uploads/2020/02/digitalized-agriculture.jpg",null));
        images.add(new SlideModel("https://thumbs.dreamstime.com/b/eggplant-plantations-grow-field-vegetable-rows-farming-agriculture-landscape-agricultural-land-crops-banner-144290553.jpg",null));
        images.add(new SlideModel("https://www.app.com.pk/wp-content/uploads/2021/05/4d799a28-fc4f-4ff2-b89c-947510e13c78.jpg",null));
        images.add(new SlideModel("https://www.youjia-china.com/wp-content/themes/wurenji/images/banner-ar2.jpg","فصلوں کو چھڑکنے کے لیے ڈرون ایک موثر حل ہے۔",null));

        imageSlider.setImageList(images,ScaleTypes.FIT);

        imageSlider.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemSelected(int i) {
                Toast.makeText(MainActivity.this, "Clicked", Toast.LENGTH_SHORT).show();
            }
        });

        weather.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), Weather.class));
            }
        });


        crops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), Crops_Menu.class));
            }
        });

        news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), News.class));
            }
        });


        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this, Chat.class);
                intent.putExtra("visit_user_id", Phone);
                intent.putExtra("visit_user_name","ProGro Farmer Chat");
                intent.putExtra("user_id", "Admin");
                startActivity(intent);
            }
        });

        inventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), Inventory_Menu.class));
            }
        });

        shops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), Shops.class));
            }
        });

        tasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), Tasks.class));
            }
        });

        videos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), Tutorials.class));
            }
        });
        fields.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), Fields.class));
            }
        });



        bottomNavigationView.setOnNavigationItemSelectedListener((BottomNavigationView.OnNavigationItemSelectedListener) this);


    }

    @Override
    public void onBackPressed() {

        finishAffinity();
        this.finish();

    }


//this method is for bottom navigation
    @Override
    public boolean onNavigationItemSelected(@NonNull @NotNull MenuItem item) {

        int id  = item.getItemId();

        switch (id){
            case R.id.home_menu:
                Toast.makeText(this, "Home Clicked", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.account_menu:
                Toast.makeText(this, "Account Clicked", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.settings_menu:
                Toast.makeText(this, "Settings Clicked", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.logout_menu:
//                SharePrefence.write(SharePrefence.IS_LOGGED_IN, false);
//                SharePrefence.write(SharePrefence.password," ");
//                SharePrefence.write(SharePrefence.phoneNumber," ");

                Paper.book().destroy();
                startActivity(new Intent(this, LoginActivity.class));
                overridePendingTransition(R.anim.fade_in,R.anim.splash_out);
                finish();
                return true;
        }
        return false;
    }



    /*  public void openChat(View view) {
        Intent intent= new Intent(this, ChatActivity.class);
        intent.putExtra("visit_user_id",SharePrefence.read(SharePrefence.phoneNumber,""));
        intent.putExtra("visit_user_name","ProGro Farmer Chat");
        intent.putExtra("user_id", "Admin");
        startActivity(intent);
    }*/
}