package com.example.progro.Seeds_Germintation;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;


import com.example.progro.R;


public class Seeds_Adapter  extends FirebaseRecyclerAdapter<Seeds_Model, Seeds_Adapter.myVholder> {

    public Seeds_Adapter( FirebaseRecyclerOptions<Seeds_Model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder( myVholder holder, int position,  Seeds_Model model) {

        TextView textView = holder.kind;
        textView.setText("قسم: " + model.getKind());
        TextView textView2 = holder.sowing;
        textView2.setText("بوائی کا وقت: " + model.getSowing());
        TextView textView3 = holder.area;
        textView3.setText("علاقے: " + model.getArea());

    }


    @Override
    public myVholder onCreateViewHolder( ViewGroup parent, int viewType) {
        return new myVholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_seeds, parent, false));
    }

    public class myVholder extends RecyclerView.ViewHolder {
        TextView area;
        TextView kind;
        TextView sowing;

        public myVholder(View itemView) {
            super(itemView);
           kind = (TextView) itemView.findViewById(R.id.kindText);
           sowing = (TextView) itemView.findViewById(R.id.sowingText);
           area = (TextView) itemView.findViewById(R.id.areaText);
        }
    }


}
