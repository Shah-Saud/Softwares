package com.example.progro.CropsProtection;

public class Protection_Model {

        String Cure;
        String Img;
        String Name;
        String Symptoms;

        public Protection_Model() {
        }

    public Protection_Model(String cure, String img, String name, String symptoms) {
        Cure = cure;
        Img = img;
        Name = name;
        Symptoms = symptoms;
    }

    public String getCure() {
            return this.Cure;
        }

        public void setCure(String cure) {
            this.Cure = cure;
        }

        public String getName() {
            return this.Name;
        }

        public void setName(String name) {
            this.Name = name;
        }

        public String getSymptoms() {
            return this.Symptoms;
        }

        public void setSymptoms(String symptoms) {
            this.Symptoms = symptoms;
        }

        public String getImg() {
            return this.Img;
        }

        public void setImg(String img) {
            this.Img = img;
        }
}
