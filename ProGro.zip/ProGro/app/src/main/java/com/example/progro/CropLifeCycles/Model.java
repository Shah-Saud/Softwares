package com.example.progro.CropLifeCycles;

public class Model {
    String Description;
    String Img;
    String Name;

    public Model() {
    }

    public Model(String description, String img, String name) {
        this.Description = description;
        this.Img = img;
        this.Name = name;
    }

    public String getDescription() {
        return this.Description;
    }

    public void setDescription(String description) {
        this.Description = description;
    }

    public String getImg() {
        return this.Img;
    }

    public void setImg(String img) {
        this.Img = img;
    }

    public String getName() {
        return this.Name;
    }

    public void setName(String name) {
        this.Name = name;
    }
}
