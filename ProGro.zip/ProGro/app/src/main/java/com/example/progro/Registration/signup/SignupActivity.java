package com.example.progro.Registration.signup;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.progro.R;
import com.example.progro.Registration.SharePrefence;
import com.example.progro.Registration.login.LoginActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hbb20.CountryCodePicker;

public class SignupActivity extends AppCompatActivity {
    String[] provinces = {"Punjab", "Khyber Pakhtunkhwa", "Sindh", "Balochistan"};
    String[] Punjab = {"Lahore", "Faisalabad", "Rawalpindi", "Gujranwala", "Multan", "Bahawalpur", "Sargodha", "Sialkot City", "Chiniot", "Shekhupura", "Jhang City", "Dera Ghazi Khan", "Gujrat", "Rahimyar Khan", "Kasur", "Sahiwal", "Okara", "Mandi Burewala", "Saddiqabad", "Muridke", "Muzaffargarh", "Khanpur", "Gojra", "Mandi Bahauddin", "Bahawalnagar", "Pakpattan", "Ahmadpur East", "Vihari", "Jaranwala", "Kamalia", "Kot Addu", "Khushab", "Chishtian", "Hasilpur", "Attock Khurd", "Mianwali", "Jalalpur Jattan", "Bhakkar", "Dipalpur", "Kharian", "Mian Channun", "Bhalwal", "Pattoki", "Harunabad", "Kahror Pakka", "Toba Tek Singh", "Samundri", "Shakargarh", "Sambrial", "Shujaabad", "Hujra Shah Muqim", "Kabirwala", "Lala Musa", "Chunian", "Nankana Sahib", "Pasrur", "Chenab Nagar", "Abdul Hakim", "Hassan Abdal", "Kundian", "Narowal", "Khanewal", "Jhelum", "Hafizabad", "Lodhran", "Attock City", "Leiah", "Chakwal", "Rajanpur"};
    String[] KPK = {"Peshawar", "Saidu Sharif", "Mardan", "Mingaora", "Kohat", "Abbottabad", "Nowshera", "Swabi", "Dera Ismail Khan", "Charsadda", "Mansehra", "Bannu", "Timargara", "Parachinar", "Tank", "Hangu", "Risalpur Cantonment", "Karak", "Chitral", "Kulachi", "Haripur", "Malakand", "Batgram", "Alpurai", "Daggar", "Lakki", "Upper Dir", "Dasu"};
    String[] Sindh = {"Karachi", "Hyderabad City", "Sukkur", "Larkana", "Nawabshah", "Mirpur Khas", "Jacobabad", "Dadu", "Tando Allahyar", "Kandhkot", "Jamshoro", "Umarkot", "Khairpur Mir’s", "Shikarpur", "Matiari", "Ghotki", "Naushahro Firoz", "Tando Muhammad Khan", "Badin", "Shahdad Kot", "Sanghar", "Thatta"};
    String[] Balochistan = {"Quetta", "Turbat", "Khuzdar", "Chaman", "Zhob", "Gwadar", "Kalat", "Dera Allahyar", "Pishin", "Dera Murad Jamali", "Kohlu", "Mastung", "Loralai", "Barkhan", "Musa Khel Bazar", "Ziarat", "Gandava", "Sibi", "Dera Bugti", "Uthal", "Khuzdar", "Panjgur", "Qila Saifullah", "Kharan", "Awaran", "Dalbandin"};


    private String provinceText, cityText;
    private Spinner spinnerProvince, spinnerCites;
    private int provinceIndex;
    private ArrayAdapter<String> adapter_provinces, adapter_cities;

    Context mContext;
    CountryCodePicker ccp;
    View progressBar;
    RelativeLayout whiteLayout;
    EditText editTextName, editTextPhn, editTextPassword, editTextConfirmPassword;
    Button btnSignUp;
    String phoneNumber;
    long userId;
    DatabaseReference dbRef;
    private FirebaseAuth mAuth;
    String mCustomToken;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        spinnerProvince = findViewById(R.id.spinnerProv);
        spinnerCites = findViewById(R.id.spinnerCity);

        mContext = this;
        SharePrefence.init(mContext);
        whiteLayout = findViewById(R.id.white_layout);
        editTextName = findViewById(R.id.name);
        editTextPhn = findViewById(R.id.edit_text_num);
        editTextPassword = findViewById(R.id.password);
        editTextConfirmPassword = findViewById(R.id.rePassword);
        btnSignUp = findViewById(R.id.btn_sign_up);
        progressBar = (View) findViewById(R.id.progress_Bar);
        ccp = findViewById(R.id.cc);

        // set animation
        Animation myanim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        whiteLayout.setAnimation(myanim);


        initSetUp();
        dbRef = FirebaseDatabase.getInstance().getReference("Users");

        //Loading Province Data into Spinner
        LoadProvinceData();

        spinnerProvince.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                provinceText = spinnerProvince.getSelectedItem().toString();
                provinceIndex = spinnerProvince.getSelectedItemPosition();
                LoadCitiesData(provinceIndex);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerCites.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cityText = spinnerCites.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void initSetUp() {
        ccp.registerCarrierNumberEditText(editTextPhn);
        ccp.setPhoneNumberValidityChangeListener(new CountryCodePicker.PhoneNumberValidityChangeListener() {
            @Override
            public void onValidityChanged(boolean isValidNumber) {

            }
        });
        editTextPhn.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keycode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keycode == KeyEvent.KEYCODE_ENTER) {
                    ValidatePhone();


                }
                return false;
            }
        });

    }


    public void openLogin(View view) {
        startActivity(new Intent(mContext, LoginActivity.class));
        finish();
    }

    public void signUpBtnClick(View view) {

        SignUpModel signUpModel = new SignUpModel();
        String name, password, confirmPass, phn;
        name = editTextName.getText().toString();
        password = editTextPassword.getText().toString();
        confirmPass = editTextConfirmPassword.getText().toString();
        phoneNumber = editTextPhn.getText().toString();
        ValidatePhone();


        if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(phoneNumber)) {
            if (!TextUtils.isEmpty(password) && !TextUtils.isEmpty(confirmPass)) {
                if (password.length() > 6) {
                    if (password.equals(confirmPass)) {
                        signUpModel.setName(name);
                        signUpModel.setProvince(provinceText);
                        signUpModel.setCity(cityText);
                        signUpModel.setPassword(password);
                        signUpModel.setPhone(phoneNumber);

                        Log.e("checksOnFields", "signUpBtnClick: ");
                        progressBar.setVisibility(View.VISIBLE);
                        checkChilds(signUpModel);

                    } else {
                        showMessage("password does't match !");

                    }
                } else {
                    showMessage("Password should be greater than Six Digits !");
                }
            } else {
                showMessage("Password should't be Empty !");
            }
        } else {
            showMessage("Name or Phone Cannot be Empty !");
        }


    }

    void showMessage(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
    }

    void checkChilds(SignUpModel signUpModel) {
        userId = 0;
        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userId = snapshot.getChildrenCount() + 1;
                signUpModel.setId(userId);
                Log.e("childCount", "onDataChange: " + userId);
                callFirebase(signUpModel);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
            }

        });
    }


    void callFirebase(SignUpModel signUpModel) {
        dbRef.child(phoneNumber).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Toast.makeText(mContext, "Account already exist", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                } else {
                    dbRef.child(phoneNumber).setValue(signUpModel).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {

                            progressBar.setVisibility(View.GONE);
                            startActivity(new Intent(mContext, LoginActivity.class));
                            finish();

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressBar.setVisibility(View.GONE);
                            showMessage("Sign Up Failed try again...");
                        }
                    });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
            }
        });


    }

    private void ValidatePhone() {
        if (ccp.isValidFullNumber()) {

            phoneNumber = ccp.getFullNumberWithPlus();
//            SharePrefence.write(SharePrefence.phoneNumber,phoneNumber);
            Log.e("SignUp", "ValidatePhone: " + phoneNumber);
        } else {
            Toast.makeText(mContext, "Invalid Phone Number", Toast.LENGTH_SHORT).show();
        }


    }

    private void LoadProvinceData() {

        adapter_provinces = new ArrayAdapter<String>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, provinces);
        spinnerProvince.setAdapter(adapter_provinces);
    }

    private void LoadCitiesData(int provinceIndex) {

        if (provinceIndex == 0) {
            adapter_cities = new ArrayAdapter<String>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, Punjab);
        } else if (provinceIndex == 1) {
            adapter_cities = new ArrayAdapter<String>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, KPK);
        } else if (provinceIndex == 2) {
            adapter_cities = new ArrayAdapter<String>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, Sindh);
        } else {
            adapter_cities = new ArrayAdapter<String>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, Balochistan);
        }

        spinnerCites.setAdapter(adapter_cities);
    }



}