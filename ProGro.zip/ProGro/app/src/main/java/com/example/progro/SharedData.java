package com.example.progro;

import android.app.Application;
import android.content.Context;

import io.paperdb.Paper;

public class SharedData extends Application {

    private static Context context;
    @Override
    public void onCreate() {
        super.onCreate();

        SharedData.context=getApplicationContext();
        Paper.init(context);

    }
    public static Context getAppContext(){
        return SharedData.context;
    }
}
