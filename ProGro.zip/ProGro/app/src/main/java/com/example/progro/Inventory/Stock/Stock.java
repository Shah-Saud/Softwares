package com.example.progro.Inventory.Stock;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.LoadingDailog;
import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import io.paperdb.Paper;

public class Stock extends AppCompatActivity {

    Stock_Adapter myAdpter;
    RecyclerView recview;
    FloatingActionButton floatingActionButton;
    private TextView noDatatv;

    //getting phonenumber of user
    String Phone = Paper.book().read("Phone");
    String child="Stocks";
    DatabaseReference checkRef = FirebaseDatabase.getInstance().getReference("Inventory/" + Phone + "/Stock");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stock);

        floatingActionButton=findViewById(R.id.floating_btn_stock);
        noDatatv = findViewById(R.id.noData_txt);
        showLoading();


        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rec_view_stock);
        recview = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Stock_Adapter myAdpter1 = new Stock_Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance()
                .getReference().child("Inventory/"+Phone+"/Stock"), Stock_Model.class).build());
        myAdpter = myAdpter1;
        recview.setAdapter(myAdpter1);

        CheckData(Phone,child);


        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Inventory_Stock_Addrec.class));
            }
        });
    }

    public void onStart() {
        super.onStart();
        myAdpter.startListening();
    }


    @Override
    public void onStop() {
        super.onStop();
        myAdpter.stopListening();
    }

    private void CheckData(String phone, String child) {
        checkRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {

                if(snapshot.hasChildren()){
                    noDatatv.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }
    //this method is for loading dialog

    public void showLoading(){
        final LoadingDailog loadingDailog = new LoadingDailog(Stock.this);
        loadingDailog.startLoading();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDailog.closeLoading();
            }
        } ,5000);
    }

}