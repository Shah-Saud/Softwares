package com.example.progro.CropLifeCycles;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.LoadingDailog;
import com.example.progro.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CropLifeCycles extends AppCompatActivity {
    private ArrayList<Model> ModelList;
    private Context mContext;
    private DatabaseReference myRef;
    private RecViewAdpter recViewAdpter;
    RecyclerView recyclerView;
    ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_life_cycles);

        btnBack = (ImageView) findViewById(R.id.btnBack);
        showLoading();



        this.recyclerView = (RecyclerView) findViewById(R.id.rec_view);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.recyclerView.setHasFixedSize(true);
        this.myRef = FirebaseDatabase.getInstance().getReference();
        this.ModelList = new ArrayList<>();
        ClearAll();
        GetDataFromFirebase();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                CropLifeCycles.this.finish();
            }
        });
    }

    private void GetDataFromFirebase() {
        this.myRef.child("CropsLifeCycles").addValueEventListener(new ValueEventListener() {
            /* class com.example.farmersdashborad.CropLifeCycles.CropLifeCycles.AnonymousClass1 */

            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot datasnapshot) {
                for (DataSnapshot snapshot : datasnapshot.getChildren()) {
                    Model model = new Model();
                    model.setName(snapshot.child("Name").getValue().toString());
                    model.setDescription(snapshot.child("Description").getValue().toString());
                    model.setImg(snapshot.child("Img").getValue().toString());
                    CropLifeCycles.this.ModelList.add(model);
                }
                CropLifeCycles.this.recViewAdpter = new RecViewAdpter(CropLifeCycles.this.getApplicationContext(), CropLifeCycles.this.ModelList);
                CropLifeCycles.this.recyclerView.setAdapter(CropLifeCycles.this.recViewAdpter);
                CropLifeCycles.this.recViewAdpter.notifyDataSetChanged();
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
            }
        });
    }

    private void ClearAll() {
        ArrayList<Model> arrayList = this.ModelList;
        if (arrayList != null) {
            arrayList.clear();
            RecViewAdpter recViewAdpter2 = this.recViewAdpter;
            if (recViewAdpter2 != null) {
                recViewAdpter2.notifyDataSetChanged();
                return;
            }
            return;
        }
        this.ModelList = new ArrayList<>();
    }
    public void showLoading(){
        final LoadingDailog loadingDailog = new LoadingDailog(CropLifeCycles.this);
        loadingDailog.startLoading();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDailog.closeLoading();
            }
        } ,5000);
    }
}