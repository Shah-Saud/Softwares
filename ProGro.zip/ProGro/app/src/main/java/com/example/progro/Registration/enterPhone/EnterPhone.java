package com.example.progro.Registration.enterPhone;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.progro.R;
import com.example.progro.Registration.OtpScreen.OtpActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hbb20.CountryCodePicker;

public class EnterPhone extends AppCompatActivity {

    EditText newphone,newpass,cnfrmPass;
    DatabaseReference dbRef;
    View progressBar;
    CountryCodePicker ccp;
    String  phoneNumber;
    boolean isNumberExist=false;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_enter);

        dbRef = FirebaseDatabase.getInstance().getReference("Users");
        newphone =findViewById(R.id.edit_text_num);
        newpass =findViewById(R.id.newpass);
        cnfrmPass =findViewById(R.id.cnfrm_pass);
        ccp = findViewById(R.id.cc);
        progressBar = (View) findViewById(R.id.progress_Bar);
        context=this;
        initSetUp();
    }

    private void initSetUp() {
        ccp.registerCarrierNumberEditText(newphone);

        ccp.setPhoneNumberValidityChangeListener(new CountryCodePicker.PhoneNumberValidityChangeListener() {
            @Override
            public void onValidityChanged(boolean isValidNumber) {

            }
        });
        newphone.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keycode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keycode == KeyEvent.KEYCODE_ENTER) {
                    ValidatePhone();


                }
                return false;
            }
        });
    }

    private void ValidatePhone() {
        if (ccp.isValidFullNumber()) {
            phoneNumber = ccp.getFullNumberWithPlus();

            Log.e("SignUp", "ValidatePhone: " + phoneNumber);

        } else {
            Toast.makeText(this, "Invalid Number", Toast.LENGTH_SHORT).show();
        }
    }

    public void next(View view)
    {
        isNumberExist=false;
        ValidatePhone();
        Log.e("phone", "next: "+phoneNumber );
        if (!TextUtils.isEmpty(phoneNumber)) {
            progressBar.setVisibility(View.VISIBLE);
            dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {

                        for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                            if (snapshot1.exists()) {
                                if (snapshot1.getKey().contains(phoneNumber)) {
                                    isNumberExist = true;
                                }
                            }
                        }
                        if (isNumberExist) {
                            Intent intent = new Intent(context, OtpActivity.class);
                            intent.putExtra("contact",phoneNumber);
                            progressBar.setVisibility(View.GONE);
                            startActivity(intent);
                            overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                            finish();
                        }
                        else {
                            Toast.makeText(context, "Sign up first", Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                    else
                        Toast.makeText(context, "Sign up first", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    progressBar.setVisibility(View.GONE);
                }
            });

        }
        else{
            Toast.makeText(this, "Please enter your Phone", Toast.LENGTH_SHORT).show();
        }


    }
}