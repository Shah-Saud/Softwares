package com.example.progro.Registration.signup;

public class SignUpModel {
    String name;
    String phone;
    String province;
    String city;
    String password;
    long id;


    public SignUpModel() {
    }

    public SignUpModel(String name, String phone, String province, String city, String password, long id) {
        this.name = name;
        this.phone = phone;
        this.province = province;
        this.city = city;
        this.password = password;
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


    public void setProvince(String province) {
        this.province = province;
    }

    public String getProvince() {
        return province;
    }


    public void setCity(String city) {
        this.city = city;
    }

    public String getCity() {
        return city;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
