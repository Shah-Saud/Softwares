package com.example.progro.CropsVarity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.LoadingDailog;
import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Pulses_Varieties extends AppCompatActivity {
    Variety_Adapter myAdpter1;
    RecyclerView recview1;
    ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pulses_varieties);

        btnBack = (ImageView) findViewById(R.id.btnBack);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recview1);

        showLoading();



        this.recview1 = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Variety_Adapter adapterVCrops = new Variety_Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance().getReference().child("Crops_Varieties/Pulses_Varieties"), Variety_Model.class).build());
        this.myAdpter1 = adapterVCrops;
        this.recview1.setAdapter(adapterVCrops);


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                Pulses_Varieties.this.finish();
            }
        });
    }


    @Override
    public void onStart() {
        super.onStart();
        this.myAdpter1.startListening();
    }


    @Override
    public void onStop() {
        super.onStop();
        this.myAdpter1.stopListening();
    }

    public void showLoading(){
        final LoadingDailog loadingDailog = new LoadingDailog(Pulses_Varieties.this);
        loadingDailog.startLoading();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDailog.closeLoading();
            }
        } ,3000);
    }
}