package com.example.progro.Chat;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.progro.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public  class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder>
{
    private List<Messages> userMessagesList;
    private FirebaseAuth mAuth;
    private DatabaseReference usersRef;
    private Context context;
    private String sender_id;

    public MessageAdapter(List<Messages> userMessagesList, Context context, String sender_id) {
        this.userMessagesList = userMessagesList;
        this.mAuth = mAuth;
        this.usersRef = usersRef;
        this.context = context;
        this.sender_id = sender_id;
    }

    @NonNull
    @NotNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custom_messages_layout, parent, false);

        mAuth = FirebaseAuth.getInstance();

        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MessageViewHolder holder, int position) {

        String messageSenderId = sender_id;
        Messages messages = userMessagesList.get(position);

        String fromUserID = messages.getFrom();
        String fromMessageType = messages.getType();

        RelativeLayout.LayoutParams lparams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        lparams.addRule(RelativeLayout.BELOW,R.id.message_receiver_image_view);
        lparams.addRule(RelativeLayout.END_OF,R.id.message_profile_image);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.BELOW,R.id.message_sender_image_view);


        usersRef = FirebaseDatabase.getInstance().getReference().child("Users").child(fromUserID);

        usersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if (snapshot.hasChild("image"))
                {
                    String receiverImage = snapshot.child("image").getValue().toString();
                    Glide.with(context).load(receiverImage).placeholder(R.drawable.ic_baseline_account_circle_24).into(holder.receiverProfileImage);

                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
        holder.receiverMessageText.setVisibility(View.GONE);
        holder.receiverProfileImage.setVisibility(View.GONE);
        holder.senderMessageText.setVisibility(View.GONE);
        holder.receiverMessageDate.setVisibility(View.GONE);
        holder.senderMessageDate.setVisibility(View.GONE);
        holder.messageSenderPicture.setVisibility(View.GONE);
        holder.messageReceiverPicture.setVisibility(View.GONE);


        if (fromMessageType.equals("text"))
        {
            if (fromUserID.equals(messageSenderId))
            {


                holder.senderMessageDate.setVisibility(View.VISIBLE);
                holder.senderMessageDate.setText(messages.getTime() + " - " + messages.getDate());

                holder.senderMessageText.setTextColor(Color.BLACK);


                if(!TextUtils.isEmpty(messages.getMessage()))
                {
                    holder.senderMessageText.setVisibility(View.VISIBLE);
                    holder.senderMessageText.setText(messages.getMessage());
                    Log.e("senderMessage", "onBindViewHolder: "+messages.getMessage() );
                }
                if(!TextUtils.isEmpty(messages.getImageUrl()))
                {
                    holder.messageSenderPicture.setVisibility(View.VISIBLE);
                    Glide.with(context).load(messages.getImageUrl()).into(holder.messageSenderPicture);
                    Log.e("senderImagUrl", "onBindViewHolder: "+messages.getImageUrl() );
                    holder.senderMessageDate.setLayoutParams(params);
                }
            }
            else
            {
                Log.e("url", "onBindViewHolder: "+messages.getImageUrl() );
                holder.receiverProfileImage.setVisibility(View.VISIBLE);
                holder.receiverMessageDate.setVisibility(View.VISIBLE);
                holder.receiverMessageDate.setText(messages.getTime() + " - " + messages.getDate());

                holder.receiverMessageText.setTextColor(Color.WHITE);


                if(!TextUtils.isEmpty(messages.getMessage()))
                {
                    holder.receiverMessageText.setVisibility(View.VISIBLE);
                    holder.receiverMessageText.setText(messages.getMessage());
                    Log.e("MessageReceiver", "onBindViewHolder: "+messages.getMessage() );
                }
                if(!TextUtils.isEmpty(messages.getImageUrl()))
                {
                    holder.messageReceiverPicture.setVisibility(View.VISIBLE);
                    Glide.with(context).load(messages.getImageUrl()).into(holder.messageReceiverPicture);
                    Log.e("receiverImagUrl", "onBindViewHolder: "+messages.getImageUrl() );
                    holder.receiverMessageDate.setLayoutParams(lparams);
                }



            }
        }

    }

    @Override
    public int getItemCount() {
        return 0;
    }


    public class MessageViewHolder extends RecyclerView.ViewHolder
    {
        public TextView senderMessageText, receiverMessageText,senderMessageDate,receiverMessageDate;
        public CircleImageView receiverProfileImage;
        public ImageView messageSenderPicture, messageReceiverPicture;


        public MessageViewHolder(@NonNull View itemView)
        {
            super(itemView);

            senderMessageText = (TextView) itemView.findViewById(R.id.sender_message_text);
            receiverMessageText = (TextView) itemView.findViewById(R.id.receiver_message_text);
            senderMessageDate = (TextView) itemView.findViewById(R.id.sender_message_date);
            receiverMessageDate = (TextView) itemView.findViewById(R.id.receiver_message_date);
            receiverProfileImage = (CircleImageView) itemView.findViewById(R.id.message_profile_image);
            messageReceiverPicture = itemView.findViewById(R.id.message_receiver_image_view);
            messageSenderPicture = itemView.findViewById(R.id.message_sender_image_view);
        }
    }

}

