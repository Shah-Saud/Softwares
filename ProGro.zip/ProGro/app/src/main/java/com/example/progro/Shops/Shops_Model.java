package com.example.progro.Shops;

public class Shops_Model {
    String Address,MapLink,ShopName;

   public Shops_Model(){

   }

    public Shops_Model(String address, String mapLink, String shopName) {
        Address = address;
        MapLink = mapLink;
        ShopName = shopName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getMapLink() {
        return MapLink;
    }

    public void setMapLink(String mapLink) {
        MapLink = mapLink;
    }

    public String getShopName() {
        return ShopName;
    }

    public void setShopName(String shopName) {
        ShopName = shopName;
    }
}
