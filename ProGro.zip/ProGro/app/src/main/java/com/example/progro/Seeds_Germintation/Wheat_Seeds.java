package com.example.progro.Seeds_Germintation;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.LoadingDailog;
import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Wheat_Seeds extends AppCompatActivity {
    Seeds_Adapter myAdpter;
    RecyclerView recview;
    ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wheat_seeds);
        btnBack = (ImageView) findViewById(R.id.btnBack);

        showLoading();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                Wheat_Seeds.this.finish();
            }
        });

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recview);
        recview = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Seeds_Adapter myAdpter1 = new Seeds_Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance()
                .getReference().child("WheatSeeds"), Seeds_Model.class).build());
        myAdpter = myAdpter1;
        recview.setAdapter(myAdpter1);
    }

    public void onStart() {
        super.onStart();
       myAdpter.startListening();
    }


    @Override
    public void onStop() {
        super.onStop();
       myAdpter.stopListening();
    }

    public void showLoading(){
        final LoadingDailog loadingDailog = new LoadingDailog(Wheat_Seeds.this);
        loadingDailog.startLoading();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDailog.closeLoading();
            }
        } ,3000);
    }
}