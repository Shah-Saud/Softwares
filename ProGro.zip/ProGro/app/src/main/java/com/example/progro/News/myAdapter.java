package com.example.progro.News;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.annotations.NotNull;

public class myAdapter extends FirebaseRecyclerAdapter<Model,myAdapter.myViewHolder> {

    public myAdapter(@NonNull @NotNull FirebaseRecyclerOptions<Model> options) {
        super(options);
    }


    @Override
    protected void onBindViewHolder(@NonNull @NotNull myViewHolder holder, int position, @NonNull @NotNull Model model) {

        holder.header.setText(model.getHeader());
        Glide.with(holder.img1.getContext()).load(model.getImg()).into(holder.img1);

        holder.img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(holder.img1.getContext(),News_Details.class);
                intent.putExtra("linkvalue",model.getSource());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                holder.img1.getContext().startActivity(intent);
            }
        });

        holder.link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.link.getContext(),News_Details.class);
                intent.putExtra("linkvalue",model.getSource());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                holder.link.getContext().startActivity(intent);
            }
        });
    }

    @NonNull
    @NotNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerownews,parent,false);
        return new myViewHolder(view);
    }

    class myViewHolder extends RecyclerView.ViewHolder{
        ImageView img1;
        TextView header, link;

        public myViewHolder(@NonNull @org.jetbrains.annotations.NotNull View itemView) {
            super(itemView);
            img1=itemView.findViewById(R.id.img1);
            header=itemView.findViewById(R.id.header);
            link=itemView.findViewById(R.id.link);
        }
    }
}
