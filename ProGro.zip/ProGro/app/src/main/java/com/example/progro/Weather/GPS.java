package com.example.progro.Weather;

import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

public interface GPS extends LocationListener, GpsStatus.Listener{

    void onGpsStatusChanged(int i);

    void onLocationChanged(Location location);

   

    void onProviderDisabled(String str);

    void onProviderEnabled(String str);

    void onStatusChanged(String str, int i, Bundle bundle);
}
