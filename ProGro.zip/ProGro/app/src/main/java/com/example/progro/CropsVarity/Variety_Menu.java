package com.example.progro.CropsVarity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.progro.R;

public class Variety_Menu extends AppCompatActivity {
    CardView V_CaneSeeds;
    CardView V_Cotton;
    CardView V_Maize;
    CardView V_Pulses;
    CardView V_Wheat;
    CardView V_rice;
    ImageView backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_variety_menu);
//        getSupportActionBar().hide();

        backBtn = (ImageView) findViewById(R.id.btnBack);
        V_Wheat = (CardView) findViewById(R.id.Vwheat);
        V_Maize = (CardView) findViewById(R.id.Vmaize);
        V_rice = (CardView) findViewById(R.id.Vrice);
        V_Cotton = (CardView) findViewById(R.id.VCotton);
        V_CaneSeeds = (CardView) findViewById(R.id.VCaneSeeds);
        V_Pulses = (CardView) findViewById(R.id.VPulses);


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             onBackPressed();
             Variety_Menu.this.finish();
            }
        });



        V_Wheat.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
              Variety_Menu.this.startActivity(new Intent(Variety_Menu.this.getApplicationContext(), Wheat_Varieties.class));
            }
        });
       V_Maize.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Variety_Menu.this.startActivity(new Intent(Variety_Menu.this.getApplicationContext(), Maize_Varieties.class));
            }
        });
      V_rice.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Variety_Menu.this.startActivity(new Intent(Variety_Menu.this.getApplicationContext(), Rice_Varieties.class));
            }
        });
        V_Cotton.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Variety_Menu.this.startActivity(new Intent(Variety_Menu.this.getApplicationContext(), Cotton_Varieties.class));
            }
        });
        V_CaneSeeds.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Variety_Menu.this.startActivity(new Intent(Variety_Menu.this.getApplicationContext(), SugarCane_Varieties.class));
            }
        });
       V_Pulses.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Variety_Menu.this.startActivity(new Intent(Variety_Menu.this.getApplicationContext(), Pulses_Varieties.class));
            }
        });


    }
}