package com.example.progro.Fields;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;
import com.travijuu.numberpicker.library.NumberPicker;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

import io.paperdb.Paper;

public class Fields_Adapter extends FirebaseRecyclerAdapter<Fields_Model,Fields_Adapter.myViewHolder> {

    String selectedLand="";
    String Phone = Paper.book().read("Phone");
    String Province = Paper.book().read("Province");
    String City = Paper.book().read("City");
    private String Status;
    private String Key;


    public Fields_Adapter(@NonNull @NotNull FirebaseRecyclerOptions<Fields_Model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull @NotNull myViewHolder holder, int position, @NonNull @NotNull Fields_Model model) {
        holder.fieldName.setText(model.getField_Name());
        holder.fieldSize.setText(model.getField_Size()+" Acre");
        holder.fieldType.setText(model.getLand_Type());
        holder.cropName.setText(model.getCrop());
        holder.year.setText(model.getYear());
        holder.Fertilizers.setText(model.getFertilizers());
        holder.Yield.setText(model.getYield()+" maunds/acre");
        Key = model.getKey();



        //work with edit btn

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NumberPicker numberPicker;
                NumberPicker yieldPicker;


                String [] landTypes= {"Silty","Sandy","Clayey","Loamy","Calcareous","Clayey and Silty","Clayey and Sandy","Loamy and Silty"};
                ArrayAdapter<String> adapterLand;



                Map<String,Object> map = new HashMap<>();

                Context context = holder.fieldName.getContext();
                final DialogPlus dialogPlus = DialogPlus.newDialog(context)
                        .setContentHolder(new ViewHolder(R.layout.fields_update_popup))
                        .setExpanded(true,1500).create();


                View view = dialogPlus.getHolderView();

                //Accessing all the fields inside popup

                EditText fieldName = (EditText) view.findViewById(R.id.txtName);
                Spinner landType = (Spinner) view.findViewById(R.id.spinnerLand);
                EditText crop = (EditText) view.findViewById(R.id.txtCrop);
                EditText fertilizers = (EditText) view.findViewById(R.id.txtFertilizer);
                DatePicker datePicker = (DatePicker) view.findViewById(R.id.datePicker);
                Button Save = (Button) view.findViewById(R.id.btnUpdate);
                yieldPicker = (NumberPicker) view.findViewById(R.id.Yield_picker);
                numberPicker = (NumberPicker) view.findViewById(R.id.fieldSize_picker);
                RadioButton radioPrivate =(RadioButton) view.findViewById(R.id.radioPrivate);
                RadioButton radioPublic = (RadioButton) view.findViewById(R.id.radioPublic);
                Button btnUpdate = view.findViewById(R.id.btnUpdate);




                datePicker.findViewById(context.getResources().getIdentifier("day","id","android")).setVisibility(View.GONE);



                //Number picker for landSize

                numberPicker.setMin(5);
                numberPicker.setUnit(1);
                numberPicker.setValue(10);

                //Number picker for yield


                yieldPicker.setMin(5);
                yieldPicker.setUnit(5);
                yieldPicker.setValue(20);

                //Number picker is not working......

                adapterLand = new ArrayAdapter<String>(holder.fieldName.getContext(),R.layout.support_simple_spinner_dropdown_item, landTypes);
                landType.setAdapter(adapterLand);
                int spinnerPosition = adapterLand.getPosition(model.getLand_Type());
                landType.setSelection(spinnerPosition);

                landType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        selectedLand = landType.getSelectedItem().toString();


                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });


                fieldName.setText(model.getField_Name());
                crop.setText(model.getCrop());
                fertilizers.setText(model.getFertilizers());


                if(model.getStatus().toLowerCase().equals("public")){
                    radioPublic.setChecked(true);
                }else {
                    radioPrivate.setChecked(true);
                }
                Key= model.getKey();

                dialogPlus.show();




                btnUpdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Map <String,Object> map = new HashMap<>();



                        //updating data
                        String FieldName,FieldSize,LandType,Crop,Year,Fertilizers,Yield,status,phone,key;


                        if(radioPublic.isChecked()){
                            Status="public";
                        }else {
                            Status="private";
                        }



                        FieldName = fieldName.getText().toString();
                        FieldSize = String.valueOf(numberPicker.getValue());
                        LandType = selectedLand;
                        Crop = crop.getText().toString();
                        Year = datePicker.getMonth()+","+datePicker.getYear();
                        Fertilizers = fertilizers.getText().toString();
                        Yield = String.valueOf(yieldPicker.getValue());
                        status=Status;
                        phone=Phone;
                        key = Key;






                        Fields_Model model = new Fields_Model(Crop,Fertilizers, FieldName, FieldSize, LandType, status, Year, Yield,phone,key);

                        DatabaseReference ref= FirebaseDatabase.getInstance().getReference()
                                .child("Fields")
                                .child(Province).child(City);

                        //Fields/Khyber Pakhtunkhwa/Swabi

                        Map<String, Object> updates = new HashMap<>();
                        updates.put(Phone+"/"+key, model);
                        updates.put("PublicData/"+key, model);

                        if(FieldName.isEmpty() || Crop.isEmpty() || Fertilizers.isEmpty()){
                            Toast.makeText(context, "Please fill all the fields", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            if(Status.equals("public")){

                                ref.updateChildren(updates).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull @NotNull Task<Void> task) {
                                        if(task.isSuccessful()){
                                            Toast.makeText(context, "Data is updated successfully", Toast.LENGTH_SHORT).show();
                                        }else {

                                            //else if user make status private then remove it from public


                                        }
                                    }
                                });
                            }else {

                                ref.child("PublicData").child(key).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull @NotNull Task<Void> task) {
                                        if(task.isSuccessful()){

                                            ref.child(Phone).child(key).setValue(model).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull @NotNull Task<Void> task) {
                                                    Toast.makeText(context, "Data is updated Successfully", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        }
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull @NotNull Exception e) {
                                        Toast.makeText(context, "Data is not updated", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }






                    }
                });
















            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                DatabaseReference ref= FirebaseDatabase.getInstance().getReference()
                        .child("Fields")
                        .child(Province).child(City);

                //Fields/Khyber Pakhtunkhwa/Swabi

                Map<String, Object> updates = new HashMap<>();
                updates.put(Phone+"/"+Key, model);
                updates.put("PublicData/"+Key, model);

                if(ref.child("PublicData").getKey().equals(Key)){

                    Toast.makeText(holder.fieldName.getContext(), "Key is here", Toast.LENGTH_SHORT).show();

                }
                else {
                    Toast.makeText(holder.fieldName.getContext(), "Key is in private only", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }



    @NonNull
    @NotNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fields_userdata_singlerow,parent,false);

        return new Fields_Adapter.myViewHolder(view);
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView fieldName,fieldSize,fieldType,cropName,year,Fertilizers,Yield;
        Button btnEdit,btnDelete;

        public myViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            fieldName = (TextView) itemView.findViewById(R.id.fieldName);
            fieldSize = (TextView) itemView.findViewById(R.id.fieldSize);
            fieldType = (TextView) itemView.findViewById(R.id.fieldType);
            cropName = (TextView) itemView.findViewById(R.id.cropName);
            year = (TextView) itemView.findViewById(R.id.year);
            Fertilizers = (TextView) itemView.findViewById(R.id.Fertilizers);
            Yield = (TextView) itemView.findViewById(R.id.Yield);

            btnEdit = (Button) itemView.findViewById(R.id.btnEdit);
            btnDelete = (Button) itemView.findViewById(R.id.btnDel);
        }
    }
}
