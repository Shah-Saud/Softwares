package com.example.progro.Seeds_Germintation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.progro.R;

public class Seeds_Menu extends AppCompatActivity {


    CardView  cane,cotton,fruits,maize,pulses,rice,vegetables,wheat;
    ImageView backBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seeds_menu);
//        getSupportActionBar().hide();


        backBtn = (ImageView) findViewById(R.id.btnBack);
        wheat = (CardView) findViewById(R.id.wheat);
        maize = (CardView) findViewById(R.id.maizeSeed);
        rice = (CardView) findViewById(R.id.riceSeeds);
        cotton = (CardView) findViewById(R.id.cottonSeed);
        cane = (CardView) findViewById(R.id.CaneSeeds);
        pulses = (CardView) findViewById(R.id.PulsesSeeds);
        vegetables = (CardView) findViewById(R.id.VegetablesSeeds);
        fruits = (CardView) findViewById(R.id.FruitsSeeds);





        // all item functions
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                Seeds_Menu.this.finish();
            }
        });



        wheat.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Seeds_Menu.this.startActivity(new Intent(Seeds_Menu.this.getApplicationContext(), Wheat_Seeds.class));
            }
        });
       maize.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Seeds_Menu.this.startActivity(new Intent(Seeds_Menu.this.getApplicationContext(), Maize_Seeds.class));
            }
        });

        rice.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Seeds_Menu.this.startActivity(new Intent(Seeds_Menu.this.getApplicationContext(), Rice_Seeds.class));
            }
        });
        cotton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Seeds_Menu.this.startActivity(new Intent(Seeds_Menu.this.getApplicationContext(), Cotton_Seeds.class));
            }
        });

       cane.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Seeds_Menu.this.startActivity(new Intent(Seeds_Menu.this.getApplicationContext(), SugarCane_Seeds.class));
            }
        });
        this.pulses.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Seeds_Menu.this.startActivity(new Intent(Seeds_Menu.this.getApplicationContext(), Pulses_Seeds.class));
            }
        });
        vegetables.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Seeds_Menu.this.startActivity(new Intent(Seeds_Menu.this.getApplicationContext(), Vegetables_Seeds.class));
            }
        });
        fruits.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Seeds_Menu.this.startActivity(new Intent(Seeds_Menu.this.getApplicationContext(), Fruits_Seeds.class));
            }
        });
    }
}