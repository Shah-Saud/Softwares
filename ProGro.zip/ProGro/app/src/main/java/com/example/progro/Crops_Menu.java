package com.example.progro;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.progro.CropLifeCycles.CropLifeCycles;
import com.example.progro.CropsProtection.Protection_Menu;
import com.example.progro.CropsVarity.Variety_Menu;
import com.example.progro.Seeds_Germintation.Seeds_Menu;

public class Crops_Menu extends AppCompatActivity {
    int phone=1;


    CardView seeds,Vcrops,lifeCycle,CropsProtection;
    ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crops_menu);



        btnBack = (ImageView) findViewById(R.id.btnBack);
        seeds = (CardView) findViewById(R.id.seedsG);
        Vcrops = (CardView) findViewById(R.id.vcrops);
        CropsProtection = (CardView)  findViewById(R.id.protect);
        lifeCycle = (CardView)  findViewById(R.id.lifeCycle);


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                Crops_Menu.this.finish();
            }
        });
        seeds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Crops_Menu.this.startActivity(new Intent(Crops_Menu.this.getApplicationContext(), Seeds_Menu.class));
            }
        });

        Vcrops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Crops_Menu.this.startActivity(new Intent(Crops_Menu.this.getApplicationContext(), Variety_Menu.class));
            }
        });

        CropsProtection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Crops_Menu.this.startActivity(new Intent(Crops_Menu.this.getApplicationContext(), Protection_Menu.class));
            }
        });
        lifeCycle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Crops_Menu.this.startActivity(new Intent(Crops_Menu.this.getApplicationContext(), CropLifeCycles.class));
            }
        });


    }
}