package com.example.progro.Tasks.MyTasks;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.R;
import com.example.progro.Tasks.Tasks;
import com.example.progro.Tasks.Tasks_Model;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import io.paperdb.Paper;

public class My_Tasks extends AppCompatActivity {
    Mytasks_Adapter myAdpter;
    RecyclerView recview;
    String Phone = Paper.book().read("Phone");
    String Province = Paper.book().read("Province");
    String City = Paper.book().read("City");


    String path="Tasks/FollowedTasks/"+Province+"/"+City+"/"+Phone;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_tasks);


        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rec_view_myTasks);
        recview = recyclerView;

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Mytasks_Adapter myAdpter1 = new Mytasks_Adapter(new FirebaseRecyclerOptions.Builder().setQuery(FirebaseDatabase.getInstance()
                .getReference().child(path), Tasks_Model.class).build());
        myAdpter = myAdpter1;
        recview.setAdapter(myAdpter1);


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
        startActivity(new Intent(getApplicationContext(), Tasks.class));
    }

    public void onStart() {
        super.onStart();
        myAdpter.startListening();
    }


    @Override
    public void onStop() {
        super.onStop();
        myAdpter.stopListening();
    }
}