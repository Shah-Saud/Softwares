package com.example.progro.Tutorials.Videos;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.progro.R;
import com.example.progro.Tutorials.Tutorials;
import com.example.progro.Tutorials.Tutorials_Adapter;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

public class Videos extends AppCompatActivity {
    TextView header_txt,noDatatv;
    String path = "Tutorials/" + Tutorials_Adapter.Cat_name + "/Videos",downloadUrl,key="Videos";
    RecyclerView recyclerView;
    private static final int PERMISSION_STORAGE_CODE =1000;
    DatabaseReference checkRef = FirebaseDatabase.getInstance().getReference("Tutorials/" + Tutorials_Adapter.Cat_name);









    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videos);


        header_txt = (TextView) findViewById(R.id.header_txt);
        noDatatv = (TextView) findViewById(R.id.noData_txt);
        recyclerView = (RecyclerView) findViewById(R.id.rec_view_videos_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        header_txt.setText(Tutorials_Adapter.Cat_name);


        checkData(key);



    }

    private void checkData(String key) {
        checkRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
           if(snapshot.hasChild(key)){
           noDatatv.setVisibility(View.GONE);
           }else {
               noDatatv.setVisibility(View.VISIBLE);
           }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerOptions<Model_Videos> options = new FirebaseRecyclerOptions
                .Builder<Model_Videos>()
                .setQuery(FirebaseDatabase.getInstance().getReference().child(path), Model_Videos.class)
                .build();


        FirebaseRecyclerAdapter<Model_Videos, myViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Model_Videos, myViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull @NotNull myViewHolder holder, int position, @NonNull @NotNull Model_Videos model) {


                holder.SetVideo(Videos.this, model.getTitle(), model.getVideoLink());

                //Download button fun

                holder.download_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (checkCallingOrSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                                    PackageManager.PERMISSION_DENIED) {

                                String permission = (Manifest.permission.WRITE_EXTERNAL_STORAGE);
                                requestPermissions(new String[]{permission}, PERMISSION_STORAGE_CODE);
                            } else {
                                downloadUrl = getItem(position).getVideoLink();
                                startDownloading(downloadUrl);
                            }
                        } else {
                            downloadUrl = getItem(position).getVideoLink();
                            startDownloading(downloadUrl);
                        }
                    }
                });

            }

            @NonNull
            @NotNull
            @Override
            public myViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.videos_signle_row, parent, false);
                return new myViewHolder(view);
            }
        };

        firebaseRecyclerAdapter.startListening();
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }

    private void startDownloading(String downloadUrl) {

        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
        request.setTitle("Download");
        request.setDescription("Downloading File");
        request.allowScanningByMediaScanner();
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "" + System.currentTimeMillis());

        DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);

        manager.enqueue(request);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        myViewHolder holder = new myViewHolder(null);
        holder.player.stop();
        Intent intent = new Intent(Videos.this, Tutorials.class);
        startActivity(intent);

        this.finish();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
      switch (requestCode){
          case PERMISSION_STORAGE_CODE:
              if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                  startDownloading(downloadUrl);
              }else {
                  Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
              }
      }
    }
}