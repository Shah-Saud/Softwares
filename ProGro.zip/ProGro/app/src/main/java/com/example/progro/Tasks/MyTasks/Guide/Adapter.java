package com.example.progro.Tasks.MyTasks.Guide;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.progro.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import org.jetbrains.annotations.NotNull;

public class Adapter extends FirebaseRecyclerAdapter<Model,Adapter.myViewHolder> {


    public Adapter(@NonNull @NotNull FirebaseRecyclerOptions<Model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull @NotNull myViewHolder holder, int position, @NonNull @NotNull Model model) {

        Glide.with(holder.img.getContext())
                .load(model.getImg())
                .placeholder(R.drawable.loading)
                .error(R.drawable.error)
                .into(holder.img);


        holder.name.setText(model.getName());
        holder.details.setText(model.getDetails());
        holder.date.setText("Due Date: "+model.getDate());


    }

    @NonNull
    @NotNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.guide_signle_row,parent,false);
        return new Adapter.myViewHolder(view);
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        ImageView img;
        TextView name,details,date;
        public myViewHolder(View itemView) {
            super(itemView);

            name = (TextView) itemView.findViewById(R.id.txt_name);
            details = (TextView) itemView.findViewById(R.id.txt_details);
            date = (TextView) itemView.findViewById(R.id.txt_date);
            img = (ImageView) itemView.findViewById(R.id.img_steps);


        }
    }
}
